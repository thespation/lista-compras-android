import { useState, useEffect, useRef, useCallback } from "react";

// --- PALETTES ----------------------------------------------------------------
const PALETTES = {
  dourado: {
    name: "Dourado",
    dark: {
      bg: "#0f0f0f", bg2: "#1a1a1a", bg3: "#252525", bg4: "#2a2a2a",
      text: "#f0ead6", text2: "#aaaaaa", text3: "#666666", text4: "#444444",
      accent: "#c8a96e", accentBg: "#c8a96e22", accentBorder: "#c8a96e44",
      accentText: "#0f0f0f", border: "#252525",
      up: "#ff6666", upBg: "#ff444422", down: "#66ff99", downBg: "#44ff7722",
      navBg: "#141414", shadow: "rgba(200,169,110,0.3)",
    },
    light: {
      bg: "#faf8f2", bg2: "#f0ead6", bg3: "#e8dfca", bg4: "#ddd5bc",
      text: "#2a2215", text2: "#6b5b3e", text3: "#9a8060", text4: "#bba880",
      accent: "#a07840", accentBg: "#a0784018", accentBorder: "#a0784044",
      accentText: "#ffffff", border: "#ddd5bc",
      up: "#c0392b", upBg: "#c0392b18", down: "#27ae60", downBg: "#27ae6018",
      navBg: "#ede8dc", shadow: "rgba(160,120,64,0.25)",
    },
  },
  nord: {
    name: "Nórdica",
    dark: {
      bg: "#2e3440", bg2: "#3b4252", bg3: "#434c5e", bg4: "#4c566a",
      text: "#eceff4", text2: "#d8dee9", text3: "#8090a0", text4: "#5a6a7a",
      accent: "#88c0d0", accentBg: "#88c0d022", accentBorder: "#88c0d044",
      accentText: "#2e3440", border: "#434c5e",
      up: "#bf616a", upBg: "#bf616a22", down: "#a3be8c", downBg: "#a3be8c22",
      navBg: "#242930", shadow: "rgba(136,192,208,0.3)",
    },
    light: {
      bg: "#eceff4", bg2: "#e5e9f0", bg3: "#d8dee9", bg4: "#cdd3de",
      text: "#2e3440", text2: "#3b4252", text3: "#5a6a7a", text4: "#8090a0",
      accent: "#5e81ac", accentBg: "#5e81ac18", accentBorder: "#5e81ac44",
      accentText: "#ffffff", border: "#d0d6e2",
      up: "#bf616a", upBg: "#bf616a18", down: "#a3be8c", downBg: "#a3be8c18",
      navBg: "#e0e5ef", shadow: "rgba(94,129,172,0.25)",
    },
  },
  gruvbox: {
    name: "Gruvbox",
    dark: {
      bg: "#282828", bg2: "#3c3836", bg3: "#504945", bg4: "#665c54",
      text: "#ebdbb2", text2: "#d5c4a1", text3: "#928374", text4: "#665c54",
      accent: "#d79921", accentBg: "#d7992122", accentBorder: "#d7992144",
      accentText: "#282828", border: "#504945",
      up: "#cc241d", upBg: "#cc241d22", down: "#98971a", downBg: "#98971a22",
      navBg: "#1d2021", shadow: "rgba(215,153,33,0.3)",
    },
    light: {
      bg: "#fbf1c7", bg2: "#f2e5bc", bg3: "#ebdbb2", bg4: "#d5c4a1",
      text: "#3c3836", text2: "#504945", text3: "#7c6f64", text4: "#928374",
      accent: "#b57614", accentBg: "#b5761418", accentBorder: "#b5761444",
      accentText: "#fbf1c7", border: "#d5c4a1",
      up: "#9d0006", upBg: "#9d000618", down: "#79740e", downBg: "#79740e18",
      navBg: "#ede8ca", shadow: "rgba(181,118,20,0.25)",
    },
  },
  rosePine: {
    name: "Rosé Pine",
    dark: {
      bg: "#191724", bg2: "#1f1d2e", bg3: "#26233a", bg4: "#312e44",
      text: "#e0def4", text2: "#c4c0da", text3: "#726d89", text4: "#524f67",
      accent: "#eb6f92", accentBg: "#eb6f9222", accentBorder: "#eb6f9244",
      accentText: "#191724", border: "#312e44",
      up: "#eb6f92", upBg: "#eb6f9222", down: "#9ccfd8", downBg: "#9ccfd822",
      navBg: "#120f20", shadow: "rgba(235,111,146,0.3)",
    },
    light: {
      bg: "#faf4ed", bg2: "#fffaf3", bg3: "#f2e9e1", bg4: "#dfdad9",
      text: "#575279", text2: "#6e6a86", text3: "#9893a5", text4: "#b4afbe",
      accent: "#b4637a", accentBg: "#b4637a18", accentBorder: "#b4637a44",
      accentText: "#faf4ed", border: "#dfdad9",
      up: "#b4637a", upBg: "#b4637a18", down: "#286983", downBg: "#28698318",
      navBg: "#f0e9e0", shadow: "rgba(180,99,122,0.25)",
    },
  },
  meiaNoite: {
    name: "Meia-Noite",
    dark: {
      bg: "#000000", bg2: "#0a0a0a", bg3: "#111111", bg4: "#1a1a1a",
      text: "#ffffff", text2: "#cccccc", text3: "#666666", text4: "#333333",
      accent: "#4fc3f7", accentBg: "#4fc3f722", accentBorder: "#4fc3f744",
      accentText: "#000000", border: "#111111",
      up: "#ff5252", upBg: "#ff525222", down: "#69f0ae", downBg: "#69f0ae22",
      navBg: "#000000", shadow: "rgba(79,195,247,0.3)",
    },
    light: {
      bg: "#f5f5f5", bg2: "#eeeeee", bg3: "#e0e0e0", bg4: "#bdbdbd",
      text: "#212121", text2: "#424242", text3: "#757575", text4: "#9e9e9e",
      accent: "#0288d1", accentBg: "#0288d118", accentBorder: "#0288d144",
      accentText: "#ffffff", border: "#e0e0e0",
      up: "#d32f2f", upBg: "#d32f2f18", down: "#388e3c", downBg: "#388e3c18",
      navBg: "#eeeeee", shadow: "rgba(2,136,209,0.25)",
    },
  },
  papel: {
    name: "Papel",
    dark: {
      bg: "#000000", bg2: "#0d0d0d", bg3: "#1a1a1a", bg4: "#262626",
      text: "#f5f0e8", text2: "#c8bfa8", text3: "#6b6050", text4: "#3d3530",
      accent: "#e8c97a", accentBg: "#e8c97a22", accentBorder: "#e8c97a44",
      accentText: "#000000", border: "#1a1a1a",
      up: "#e07070", upBg: "#e0707022", down: "#7ec88a", downBg: "#7ec88a22",
      navBg: "#000000", shadow: "rgba(232,201,122,0.3)",
    },
    light: {
      bg: "#ffffff", bg2: "#fafaf8", bg3: "#f2f0eb", bg4: "#e8e4db",
      text: "#1a1410", text2: "#4a3f2f", text3: "#8a7a60", text4: "#b8a888",
      accent: "#7a5c20", accentBg: "#7a5c2018", accentBorder: "#7a5c2044",
      accentText: "#ffffff", border: "#e8e4db",
      up: "#b03030", upBg: "#b0303018", down: "#2a7a3a", downBg: "#2a7a3a18",
      navBg: "#f2f0eb", shadow: "rgba(122,92,32,0.2)",
    },
  },
  catppuccin: {
    name: "Catppuccin",
    dark: {
      bg: "#1e1e2e", bg2: "#181825", bg3: "#313244", bg4: "#45475a",
      text: "#cdd6f4", text2: "#bac2de", text3: "#7f849c", text4: "#585b70",
      accent: "#cba6f7", accentBg: "#cba6f722", accentBorder: "#cba6f744",
      accentText: "#1e1e2e", border: "#313244",
      up: "#f38ba8", upBg: "#f38ba822", down: "#a6e3a1", downBg: "#a6e3a122",
      navBg: "#11111b", shadow: "rgba(203,166,247,0.3)",
    },
    light: {
      bg: "#eff1f5", bg2: "#e6e9ef", bg3: "#dce0e8", bg4: "#ccd0da",
      text: "#4c4f69", text2: "#5c5f77", text3: "#8c8fa1", text4: "#acafc0",
      accent: "#8839ef", accentBg: "#8839ef18", accentBorder: "#8839ef44",
      accentText: "#ffffff", border: "#ccd0da",
      up: "#d20f39", upBg: "#d20f3918", down: "#40a02b", downBg: "#40a02b18",
      navBg: "#dce0e8", shadow: "rgba(136,57,239,0.25)",
    },
  },
};

const DEFAULT_MARKETS = ["Mercado A", "Mercado B", "Mercado C", "Outro"];
const MONTHS     = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
const MONTHS_FULL = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho",
                     "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
const STORAGE_KEY  = "lista-compras-v2";
const SETTINGS_KEY = "lista-compras-settings";

const SORT_OPTIONS = [
  { key: "insertion",          label: "Ordem de inserção" },
  { key: "alpha",              label: "Alfabética (A->Z)" },
  { key: "alpha-checked-last", label: "Alfabética + marcados abaixo" },
  { key: "checked-last",       label: "Inserção + marcados abaixo" },
  { key: "checked-first",      label: "Marcados primeiro" },
  { key: "price-asc",          label: "Menor preço total primeiro" },
  { key: "price-desc",         label: "Maior preço total primeiro" },
];

// --- HELPERS -----------------------------------------------------------------
function fmt(v) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v || 0);
}
function capitalize(str) {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}
function todayStr() { return new Date().toISOString().split("T")[0]; }
function monthKey(d) {
  const x = new Date(d + "T12:00");
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}`;
}
function monthLabel(k) {
  const [y, m] = k.split("-");
  return `${MONTHS[parseInt(m) - 1]}/${y.slice(2)}`;
}
function monthLabelFull(k) {
  const [y, m] = k.split("-");
  return `${MONTHS_FULL[parseInt(m) - 1]} ${y}`;
}
function listTotal(list) {
  return list.items.reduce((s, i) => s + i.qty * i.price, 0);
}
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2); }

function maskCurrency(raw) {
  const digits = raw.replace(/\D/g, "");
  if (!digits) return "";
  return (parseInt(digits, 10) / 100).toFixed(2).replace(".", ",");
}
function unmaskCurrency(masked) {
  return parseFloat((masked || "").replace(",", ".")) || 0;
}

function applySortKey(items, sortKey) {
  const arr = [...items];
  switch (sortKey) {
    case "alpha":
      return arr.sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
    case "alpha-checked-last":
      return arr.sort((a, b) => {
        if (a.checked !== b.checked) return a.checked ? 1 : -1;
        return a.name.localeCompare(b.name, "pt-BR");
      });
    case "checked-last":
      return arr.sort((a, b) => {
        if (a.checked !== b.checked) return a.checked ? 1 : -1;
        return 0;
      });
    case "checked-first":
      return arr.sort((a, b) => {
        if (a.checked !== b.checked) return a.checked ? -1 : 1;
        return 0;
      });
    case "price-asc":
      return arr.sort((a, b) => a.qty * a.price - b.qty * b.price);
    case "price-desc":
      return arr.sort((a, b) => b.qty * b.price - a.qty * a.price);
    default:
      return arr; // insertion order
  }
}

function useSystemDark() {
  const getInitial = () => {
    if (typeof window === "undefined") return true;
    // Android WebView injects this before page renders
    if (typeof window.__androidDarkMode === "boolean") return window.__androidDarkMode;
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  };
  const [dark, setDark] = useState(getInitial);
  useEffect(() => {
    // Listen for Android dark mode changes (when user toggles while app is open)
    const handleAndroid = () => {
      if (typeof window.__androidDarkMode === "boolean") setDark(window.__androidDarkMode);
    };
    window.addEventListener("androidDarkModeChange", handleAndroid);
    // Also listen to standard media query as fallback
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handleMq = (e) => {
      if (typeof window.__androidDarkMode !== "boolean") setDark(e.matches);
    };
    mq.addEventListener("change", handleMq);
    return () => {
      window.removeEventListener("androidDarkModeChange", handleAndroid);
      mq.removeEventListener("change", handleMq);
    };
  }, []);
  return dark;
}

// --- MINI CHART COMPONENTS ---------------------------------------------------
function VerticalBars({ data, t, fs }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div style={{ display: "flex", gap: 6, alignItems: "flex-end", height: 130, padding: "0 2px" }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
          {d.value > 0 && (
            <div style={{ fontSize: Math.max(8, fs - 6), color: t.accent, fontWeight: "bold", textAlign: "center", whiteSpace: "nowrap" }}>
              {fmt(d.value).replace("R$\u00a0", "R$")}
            </div>
          )}
          <div style={{ width: "100%", background: t.bg3, borderRadius: "4px 4px 0 0", overflow: "hidden", height: 90, display: "flex", alignItems: "flex-end" }}>
            <div
              style={{
                width: "100%",
                height: `${Math.max(d.value > 0 ? 6 : 0, (d.value / max) * 100)}%`,
                background: `linear-gradient(180deg, ${t.accent}, ${t.accent}88)`,
                borderRadius: "3px 3px 0 0",
                transition: "height 0.4s ease",
              }}
            />
          </div>
          <div style={{ fontSize: Math.max(8, fs - 6), color: t.text3, textAlign: "center", whiteSpace: "nowrap" }}>{d.label}</div>
        </div>
      ))}
    </div>
  );
}

function HorizontalBars({ data, t, fs }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {data.map((d, i) => (
        <div key={i}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
            <span style={{ fontSize: Math.max(10, fs - 3), color: t.text2 }}>{d.label}</span>
            <span style={{ fontSize: Math.max(10, fs - 3), color: t.accent, fontWeight: "bold" }}>{fmt(d.value)}</span>
          </div>
          <div style={{ height: 8, background: t.bg3, borderRadius: 4, overflow: "hidden" }}>
            <div
              style={{
                height: "100%",
                width: `${Math.max(d.value > 0 ? 3 : 0, (d.value / max) * 100)}%`,
                background: `linear-gradient(90deg, ${t.accent}, ${t.accent}88)`,
                borderRadius: 4,
                transition: "width 0.4s ease",
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

// --- MAIN APP -----------------------------------------------------------------
export default function App() {
  const systemDark = useSystemDark();

  const [settings, setSettings] = useState({
    paletteKey: "dourado",
    paletteMode: "dark", // "dark" | "light"
    markets: DEFAULT_MARKETS,
    customPalettes: {},
    sortKey: "insertion",
    fontSize: 15,
    swipeEnabled: true,
    hamburgerPos: "top-left",
    backBehavior: "confirm", // "confirm" | "minimize" | "nothing"
    showHamburger: true,
    tabPosition: "bottom", // "top" | "bottom"
  });
  const [data, setData] = useState({ lists: [], priceHistory: {} });

  // Navigation
  const [view, setView] = useState("home"); // start on home
  const [activeListId, setActiveListId] = useState(null);
  const [drawerOpen] = useState(false); // drawer removed — kept for safety

  // List detail
  const [newItem, setNewItem] = useState({ name: "", qty: "", price: "" });
  const [autocomplete, setAutocomplete] = useState([]);
  const [showAutocomplete, setShowAutocomplete] = useState(false);
  const [listMenuOpen, setListMenuOpen] = useState(false);
  const [listPriceFilter, setListPriceFilter] = useState(null); // null | "cheaper" | "pricier"
  const [settingsOpen, setSettingsOpen] = useState(null); // which accordion section is open
  const [showNewListForm, setShowNewListForm] = useState(false);
  // Which month groups are expanded. Current month always starts expanded.
  const [showHistory, setShowHistory] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [confirmDeletePaletteKey, setConfirmDeletePaletteKey] = useState(null);
  const [openHistoryMonths, setOpenHistoryMonths] = useState({}); // { "2026-01": true }
  const [confirmModal, setConfirmModal] = useState(null); // { title, message, onConfirm }
  const [importConfirm, setImportConfirm] = useState(null); // { parsed } — pending import waiting confirmation
  const [backupManager, setBackupManager] = useState(null); // null | { backups: [] }
  const [editingItem, setEditingItem] = useState(null);

  // Home / search
  const [searchQuery, setSearchQuery] = useState("");

  // Item price history search
  const [itemSearchQuery, setItemSearchQuery] = useState("");
  const [itemSearchSuggestions, setItemSearchSuggestions] = useState([]);
  const [itemSearchSelected, setItemSearchSelected] = useState(null);
  const [showItemSuggestions, setShowItemSuggestions] = useState(false);

  // Custom palette editor
  const [customPaletteEditor, setCustomPaletteEditor] = useState(null);
  // null | { name, darkBg, darkAccent, lightBg, lightAccent, editKey }

  // New list
  const [newListName, setNewListName] = useState("");
  const [newListMarket, setNewListMarket] = useState("");
  const [newMarketName, setNewMarketName] = useState("");
  const [editingMarketIdx, setEditingMarketIdx] = useState(null);
  const [editingMarketVal, setEditingMarketVal] = useState("");

  // Duplicate modal
  const [duplicateSource, setDuplicateSource] = useState(null);
  const [duplicateZero, setDuplicateZero] = useState(false);
  const [duplicateMarket, setDuplicateMarket] = useState(null); // market for duplicate
  const [editingListHeader, setEditingListHeader] = useState(false);
  const [updateStatus, setUpdateStatus] = useState(null);
  // null | "checking" | "up-to-date" | "available" | "error"
  const [updateInfo, setUpdateInfo] = useState(null);
  // { version, body, url }
  const [editListName, setEditListName] = useState("");
  const [editListMarket, setEditListMarket] = useState("");

  // Analysis
  const [analysisTab, setAnalysisTab] = useState("monthly");
  const [chartMode, setChartMode] = useState("hbars"); // hbars | numbers (bars removed from annual)
  const [analysisMonth, setAnalysisMonth] = useState(() => monthKey(todayStr()));

  // Settings
  const [importError, setImportError] = useState("");
  const [themeImportError, setThemeImportError] = useState("");

  // Toast
  const [toast, setToast] = useState(null);

  // Refs
  const fileInputRef = useRef();
  const themeFileRef = useRef();
  const touchStartX = useRef(null);

  // -- Theme --
  const allPalettes = { ...PALETTES, ...(settings.customPalettes || {}) };
  const isDark = (settings.paletteMode ?? "dark") === "dark";
  const palette = allPalettes[settings.paletteKey] || PALETTES.dourado;
  const t = isDark ? palette.dark : palette.light;
  const markets = settings.markets?.length ? settings.markets : DEFAULT_MARKETS;
  const fs = settings.fontSize || 15;

  // -- Persistence --
  useEffect(() => {
    try {
      const s = localStorage.getItem(SETTINGS_KEY);
      if (s) {
        const p = JSON.parse(s);
        // Migrate old format
        if (p.themeMode !== undefined) {
          p.paletteMode = p.themeMode === "light" ? "light" : "dark";
          delete p.themeMode;
        }
        delete p.themeSource;
        if (!p.paletteMode) p.paletteMode = "dark";
        if (p.swipeEnabled === undefined) p.swipeEnabled = true;
        if (!p.hamburgerPos) p.hamburgerPos = "top-left";
        setSettings(p);
        setNewListMarket(p.markets?.[0] || DEFAULT_MARKETS[0]);
      } else {
        setNewListMarket(DEFAULT_MARKETS[0]);
      }
    } catch { setNewListMarket(DEFAULT_MARKETS[0]); }
    try {
      const d = localStorage.getItem(STORAGE_KEY);
      if (d) setData(JSON.parse(d));
    } catch {}
  }, []);
  useEffect(() => { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }, [data]);

  // -- Toast --
  const showToast = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  }, []);

  // -- Swipe-to-open drawer --
  const onTouchStart = (e) => {
    if (!settings.swipeEnabled) return;
    touchStartX.current = e.touches[0].clientX;
  };
  const onTouchEnd = (e) => {
    touchStartX.current = null;
  };

  // -- Navigation helper --
  function navigate(v) {
    setView(v);
    setSearchQuery("");
    setListMenuOpen(false);
    setListPriceFilter(null);
  }

  // -- Check for updates via GitHub Releases API --
  async function checkForUpdate() {
    setUpdateStatus("checking");
    setUpdateInfo(null);
    try {
      const res = await fetch(
        "https://api.github.com/repos/thespation/lista-compras-android/releases/latest",
        { headers: { Accept: "application/vnd.github+json" } }
      );
      if (!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      const latest = (data.tag_name || "").replace(/^v/i, "");
      const current = "1.6";
      const apkAsset = (data.assets || []).find((a) => a.name.endsWith(".apk"));
      const downloadUrl = apkAsset ? apkAsset.browser_download_url : data.html_url;
      if (latest && latest !== current) {
        setUpdateStatus("available");
        setUpdateInfo({ version: latest, body: data.body || "", url: downloadUrl });
      } else {
        setUpdateStatus("up-to-date");
      }
    } catch (e) {
      setUpdateStatus("error");
    }
  }

  // -- Android back button handler (called from MainActivity.java) --
  useEffect(() => {
    window.__drawerOpen = false; // drawer no longer exists
    window.__androidBack = () => {
      if (backupManager) { setBackupManager(null); return; }
      if (importConfirm) { setImportConfirm(null); return; }
      if (confirmModal) { setConfirmModal(null); return; }
      if (customPaletteEditor) { setCustomPaletteEditor(null); return; }
      if (editingItem) { setEditingItem(null); return; }
      if (editingListHeader) { setEditingListHeader(false); return; }
      if (duplicateSource) { setDuplicateSource(null); return; }
      if (view === "list-detail") { setView("home"); setSearchQuery(""); setListMenuOpen(false); setListPriceFilter(null); return; }
      if (view === "about") { setView("settings"); return; }
      if (view === "settings" || view === "analysis") { setView("home"); return; }
      // On home: apply backBehavior setting
      const behavior = settings.backBehavior || "confirm";
      if (behavior === "confirm") {
        setConfirmModal({
          title: "Sair do app?",
          message: "Deseja fechar o Lista de Compras?",
          confirmLabel: "Sair",
          cancelLabel: "Cancelar",
          onConfirm: () => {
            if (window.AndroidBridge && window.AndroidBridge.exitApp) {
              window.AndroidBridge.exitApp();
            }
          },
        });
      } else if (behavior === "minimize") {
        if (window.AndroidBridge && window.AndroidBridge.minimizeApp) {
          window.AndroidBridge.minimizeApp();
        }
      }
      // "nothing" → do nothing
    };
    return () => { window.__androidBack = null; };
  });

  // -- List CRUD --
  const currentList = data.lists.find((l) => l.id === activeListId) || null;

  function updateList(listId, updater) {
    setData((d) => ({ ...d, lists: d.lists.map((l) => (l.id === listId ? updater(l) : l)) }));
  }

  function recordPriceHistory(itemName, price, list, baseData) {
    const ph = { ...((baseData || data).priceHistory) };
    const k = itemName.toLowerCase();
    if (!ph[k]) ph[k] = [];
    ph[k] = [
      { date: list.date, price, market: list.market },
      ...ph[k].filter((h) => !(h.date === list.date && h.market === list.market)),
    ].slice(0, 60);
    return ph;
  }

  function createList() {
    if (!newListName.trim()) return;
    const list = { id: uid(), name: newListName.trim(), market: newListMarket, date: todayStr(), items: [] };
    setData((d) => ({ ...d, lists: [list, ...d.lists] }));
    setNewListName("");
    setActiveListId(list.id);
    setShowNewListForm(false);
    setView("list-detail");
    showToast("Lista criada!");
  }

  function doDuplicate() {
    if (!duplicateSource) return;
    const copy = {
      ...duplicateSource,
      id: uid(),
      name: duplicateSource.name + " (cópia)",
      date: todayStr(),
      market: duplicateMarket || duplicateSource.market,
      items: duplicateSource.items.map((i) => ({
        ...i,
        id: uid(),
        checked: false,
        price: duplicateZero ? 0 : i.price,
        qty: i.qty,
      })),
    };
    setData((d) => ({ ...d, lists: [copy, ...d.lists] }));
    setDuplicateSource(null);
    showToast(duplicateZero ? "Duplicada com valores zerados!" : "Lista duplicada!");
  }

  function deleteList(id) {
    setData((d) => ({ ...d, lists: d.lists.filter((l) => l.id !== id) }));
    showToast("Lista removida");
  }

  // -- Item CRUD --
  function handleNameInput(val) {
    setNewItem((i) => ({ ...i, name: val }));
    if (val.length < 2) { setShowAutocomplete(false); return; }
    const lower = val.toLowerCase();
    const matches = Object.entries(data.priceHistory)
      .filter(([k]) => k.includes(lower))
      .map(([k, entries]) => {
        const sorted = [...entries].sort((a, b) => b.date.localeCompare(a.date));
        return { name: k, lastPrice: sorted[0]?.price };
      })
      .slice(0, 5);
    setAutocomplete(matches);
    setShowAutocomplete(matches.length > 0);
  }

  function handleItemSearch(val) {
    setItemSearchQuery(val);
    setItemSearchSelected(null);
    if (val.length < 2) { setShowItemSuggestions(false); setItemSearchSuggestions([]); return; }
    const lower = val.toLowerCase();
    const matches = Object.entries(data.priceHistory)
      .filter(([k]) => k.includes(lower))
      .map(([k, entries]) => {
        const valid = entries.filter((h) =>
          data.lists.some((l) => l.date === h.date && l.market === h.market)
        );
        const sorted = [...valid].sort((a, b) => b.date.localeCompare(a.date));
        return { name: k, lastPrice: sorted[0]?.price, count: valid.length };
      })
      .filter((m) => m.count > 0)
      .slice(0, 8);
    setItemSearchSuggestions(matches);
    setShowItemSuggestions(matches.length > 0);
  }

  function selectItemHistory(itemName) {
    setItemSearchQuery(itemName);
    setShowItemSuggestions(false);
    const entries = data.priceHistory[itemName] || [];
    // Only keep entries that match an existing list (same date + market)
    const validEntries = entries.filter((h) =>
      data.lists.some((l) => l.date === h.date && l.market === h.market)
    );
    const sorted = [...validEntries]
      .sort((a, b) => b.date.localeCompare(a.date))
      .slice(0, 10);
    setItemSearchSelected({ name: itemName, entries: sorted });
  }

  function buildCustomPalette(e) {
    // e = { name, darkBg, darkAccent, lightBg, lightAccent }
    const mix = (hex, amt) => {
      const n = parseInt(hex.slice(1), 16);
      const r = Math.min(255, Math.max(0, (n >> 16) + amt));
      const g = Math.min(255, Math.max(0, ((n >> 8) & 0xff) + amt));
      const b = Math.min(255, Math.max(0, (n & 0xff) + amt));
      return `#${((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1)}`;
    };
    const alpha = (hex, a) => hex + Math.round(a * 255).toString(16).padStart(2, "0");
    const dark = {
      bg: e.darkBg,
      bg2: mix(e.darkBg, 18), bg3: mix(e.darkBg, 32), bg4: mix(e.darkBg, 48),
      text: "#eceff4", text2: "#c0c8d4", text3: "#7a8898", text4: "#4a5868",
      accent: e.darkAccent,
      accentBg: alpha(e.darkAccent, 0.13), accentBorder: alpha(e.darkAccent, 0.3),
      accentText: e.darkBg, border: mix(e.darkBg, 32),
      up: "#bf616a", upBg: alpha("#bf616a", 0.13), down: "#a3be8c", downBg: alpha("#a3be8c", 0.13),
      navBg: mix(e.darkBg, -8), shadow: alpha(e.darkAccent, 0.25),
    };
    const light = {
      bg: e.lightBg,
      bg2: mix(e.lightBg, -8), bg3: mix(e.lightBg, -18), bg4: mix(e.lightBg, -30),
      text: "#2e3440", text2: "#3b4252", text3: "#6a7888", text4: "#9aaabb",
      accent: e.lightAccent,
      accentBg: alpha(e.lightAccent, 0.1), accentBorder: alpha(e.lightAccent, 0.3),
      accentText: "#ffffff", border: mix(e.lightBg, -28),
      up: "#bf616a", upBg: alpha("#bf616a", 0.1), down: "#a3be8c", downBg: alpha("#a3be8c", 0.1),
      navBg: mix(e.lightBg, -14), shadow: alpha(e.lightAccent, 0.2),
    };
    return { name: e.name || "Personalizada", dark, light };
  }

  function saveCustomPalette() {
    if (!customPaletteEditor) return;
    const pal = buildCustomPalette(customPaletteEditor);
    const key = customPaletteEditor.editKey || ("custom_" + uid());
    setSettings((s) => ({
      ...s,
      customPalettes: { ...(s.customPalettes || {}), [key]: pal },
      paletteKey: key,
      themeSource: "palette",
    }));
    setCustomPaletteEditor(null);
    showToast("Paleta salva!");
  }

  function pickAutocomplete(item) {
    setNewItem((i) => ({
      ...i,
      name: capitalize(item.name),
      // Only fill price from history if user hasn't typed a price yet
      price: i.price && i.price !== "0,00" ? i.price : (item.lastPrice ? maskCurrency(String(Math.round((item.lastPrice || 0) * 100))) : i.price),
    }));
    setShowAutocomplete(false);
  }

  // Returns { arrow: "up"|"down", pct, lastPrice } or null
  // Compares currentPrice against the most recent PREVIOUS purchase price
  // (ignores entries with the same price as currentPrice from the current list date)
  function getPriceHint(itemName, currentPrice, excludeDate, excludeMarket) {
    if (!itemName || !currentPrice) return null;
    const key = itemName.trim().toLowerCase();
    const history = data.priceHistory[key];
    if (!history || history.length === 0) return null;
    // Sort newest first, optionally excluding the current list's own entry
    const filtered = history.filter((h) =>
      !(excludeDate && excludeMarket && h.date === excludeDate && h.market === excludeMarket)
    );
    if (filtered.length === 0) return null;
    const sorted = [...filtered].sort((a, b) => b.date.localeCompare(a.date));
    const prev = sorted.find((h) => Math.abs(h.price - currentPrice) > 0.001);
    if (!prev) return null;
    const lastPrice = prev.price;
    const pct = Math.abs(((currentPrice - lastPrice) / lastPrice) * 100);
    if (pct < 0.5) return null;
    return { arrow: currentPrice > lastPrice ? "up" : "down", pct, lastPrice };
  }

  function addItem() {
    if (!newItem.name.trim() || !newItem.price || !currentList) return;
    const price = unmaskCurrency(newItem.price);
    const qty = parseInt(newItem.qty, 10) || 1;
    if (!price) return;
    // Get hint BEFORE recording history so comparison uses previous purchases
    const hint = getPriceHint(newItem.name.trim(), price);
    const item = { id: uid(), name: capitalize(newItem.name.trim()), qty, price, checked: false, priceHint: hint || null };
    const ph = recordPriceHistory(item.name, price, currentList);
    setData((d) => ({
      ...d,
      priceHistory: ph,
      lists: d.lists.map((l) =>
        l.id === currentList.id ? { ...l, items: [...l.items, item] } : l
      ),
    }));
    setNewItem((i) => ({ ...i, name: "", price: "", qty: "" }));
    setShowAutocomplete(false);
    showToast("Item adicionado!");
  }

  function toggleItem(itemId) {
    updateList(currentList.id, (l) => ({
      ...l,
      items: l.items.map((i) => (i.id === itemId ? { ...i, checked: !i.checked } : i)),
    }));
  }

  function removeItem(itemId) {
    updateList(currentList.id, (l) => ({ ...l, items: l.items.filter((i) => i.id !== itemId) }));
  }

  function saveEditItem() {
    if (!editingItem?.name.trim()) return;
    const price = unmaskCurrency(editingItem.price);
    const qty = parseInt(editingItem.qty, 10) || 1;
    // Exclude the current list's own entry so editing a typo doesn't generate a false hint
    const hint = getPriceHint(editingItem.name.trim(), price, currentList?.date, currentList?.market);
    const ph = recordPriceHistory(editingItem.name, price, currentList);
    setData((d) => ({
      ...d,
      priceHistory: ph,
      lists: d.lists.map((l) =>
        l.id === currentList.id
          ? {
              ...l,
              items: l.items.map((i) =>
                i.id === editingItem.id
                  ? { ...i, name: capitalize(editingItem.name.trim()), qty, price, priceHint: hint || null }
                  : i
              ),
            }
          : l
      ),
    }));
    setEditingItem(null);
    showToast("Item salvo!");
  }

  function markAll(checked) {
    updateList(currentList.id, (l) => ({ ...l, items: l.items.map((i) => ({ ...i, checked })) }));
    setListMenuOpen(false);
  }

  // -- Markets --
  function addMarket() {
    const name = newMarketName.trim();
    if (!name || markets.includes(name)) return;
    setSettings((s) => ({ ...s, markets: [...markets, name] }));
    setNewMarketName("");
    showToast("Mercado adicionado!");
  }
  function removeMarket(idx) {
    const updated = markets.filter((_, i) => i !== idx);
    setSettings((s) => ({ ...s, markets: updated }));
    if (newListMarket === markets[idx]) setNewListMarket(updated[0] || "");
  }
  function saveMarketEdit() {
    const val = editingMarketVal.trim();
    if (!val || editingMarketIdx === null) return;
    setSettings((s) => ({ ...s, markets: markets.map((m, i) => (i === editingMarketIdx ? val : m)) }));
    setEditingMarketIdx(null);
    setEditingMarketVal("");
    showToast("Mercado atualizado!");
  }

  // -- Themes --
  function importThemeFromFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setThemeImportError("");
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        const req = ["bg","bg2","bg3","bg4","text","text2","text3","text4","accent","accentBg","accentBorder","accentText","border","up","upBg","down","downBg","navBg","shadow"];
        if (!parsed.name || !parsed.dark || !parsed.light) throw new Error();
        for (const f of req) { if (!parsed.dark[f] || !parsed.light[f]) throw new Error(); }
        const key = "custom_" + parsed.name.toLowerCase().replace(/\s+/g, "_");
        setSettings((s) => ({
          ...s,
          customPalettes: { ...(s.customPalettes || {}), [key]: { name: parsed.name, dark: parsed.dark, light: parsed.light } },
          paletteKey: key,
          // (themeSource removed)
        }));
        showToast(`Tema "${parsed.name}" importado!`);
      } catch { setThemeImportError("Arquivo inválido. Verifique os campos dark/light."); }
    };
    reader.readAsText(file);
    e.target.value = "";
  }
  function removeCustomTheme(key) {
    setSettings((s) => {
      const cp = { ...(s.customPalettes || {}) };
      delete cp[key];
      return { ...s, customPalettes: cp, paletteKey: s.paletteKey === key ? "dourado" : s.paletteKey };
    });
    showToast("Tema removido");
  }

  // -- Data export/import --
  // ── BACKUP SYSTEM (localStorage-based, works in Android WebView) ──
  const BACKUP_INDEX_KEY = "lista-compras-backups";

  function getBackupIndex() {
    try { return JSON.parse(localStorage.getItem(BACKUP_INDEX_KEY) || "[]"); } catch { return []; }
  }

  function saveBackupIndex(index) {
    localStorage.setItem(BACKUP_INDEX_KEY, JSON.stringify(index));
  }

  function exportData() {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const ts = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
    const key = `lista-compras-backup-${Date.now()}`;
    const payload = JSON.stringify({ ...data, exportedAt: now.toISOString() });
    try {
      localStorage.setItem(key, payload);
      const index = getBackupIndex();
      index.unshift({ key, name: `Backup ${ts}`, date: now.toISOString(), size: payload.length, lists: data.lists.length });
      saveBackupIndex(index);
      showToast("Backup salvo com sucesso!");
    } catch {
      showToast("Erro ao salvar backup.");
    }
  }

  function deleteBackup(key) {
    localStorage.removeItem(key);
    const index = getBackupIndex().filter((b) => b.key !== key);
    saveBackupIndex(index);
    setBackupManager((bm) => ({ ...bm, backups: index }));
  }

  function restoreBackup(backup) {
    try {
      const raw = localStorage.getItem(backup.key);
      if (!raw) { showToast("Backup não encontrado."); return; }
      const parsed = JSON.parse(raw);
      if (!parsed.lists || !Array.isArray(parsed.lists)) { showToast("Backup inválido."); return; }
      setImportConfirm({ parsed, filename: backup.name });
    } catch { showToast("Erro ao ler backup."); }
  }

  function confirmImport() {
    if (!importConfirm) return;
    setData({ lists: importConfirm.parsed.lists, priceHistory: importConfirm.parsed.priceHistory || {} });
    showToast(`${importConfirm.parsed.lists.length} listas restauradas!`);
    setImportConfirm(null);
    setBackupManager(null);
  }


  // -- Analysis data --
  const allMonthKeys = [...new Set(data.lists.map((l) => monthKey(l.date)))].sort();

  // ensure current analysisMonth is in list, else pick last
  const safeMonth = allMonthKeys.includes(analysisMonth)
    ? analysisMonth
    : allMonthKeys[allMonthKeys.length - 1] || monthKey(todayStr());

  const annualYears = (() => {
    const yearSet = new Set(allMonthKeys.map((k) => k.split("-")[0]));
    return [...yearSet].sort().map((y) => {
      const months = MONTHS.map((label, idx) => {
        const key = `${y}-${String(idx + 1).padStart(2, "0")}`;
        const val = data.lists
          .filter((l) => monthKey(l.date) === key)
          .reduce((s, l) => s + listTotal(l), 0);
        return { label, key, value: val };
      });
      return { year: y, months, total: months.reduce((s, m) => s + m.value, 0) };
    });
  })();

  const selectedMonthLists = data.lists.filter((l) => monthKey(l.date) === safeMonth);
  const prevMonthKey = (() => {
    const [y, m] = safeMonth.split("-").map(Number);
    return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, "0")}`;
  })();
  const prevMonthLists = data.lists.filter((l) => monthKey(l.date) === prevMonthKey);

  const productComparison = (() => {
    const cur = {};
    const prev = {};
    selectedMonthLists.forEach((l) =>
      l.items.forEach((i) => {
        const k = i.name.toLowerCase();
        if (!cur[k] || i.price > cur[k]) cur[k] = i.price;
      })
    );
    prevMonthLists.forEach((l) =>
      l.items.forEach((i) => {
        const k = i.name.toLowerCase();
        if (!prev[k] || i.price > prev[k]) prev[k] = i.price;
      })
    );
    return Object.keys({ ...cur, ...prev })
      .map((k) => ({
        name: k,
        curPrice: cur[k],
        prevPrice: prev[k],
        diff: cur[k] && prev[k] ? ((cur[k] - prev[k]) / prev[k]) * 100 : null,
      }))
      .filter((p) => p.diff !== null)
      .sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff));
  })();

  const dashMarkets = (() => {
    const map = {};
    data.lists.forEach((l) => {
      if (!map[l.market]) map[l.market] = { total: 0, count: 0 };
      map[l.market].total += listTotal(l);
      map[l.market].count++;
    });
    return Object.entries(map)
      .map(([m, v]) => ({ market: m, total: v.total, avg: v.total / v.count, count: v.count }))
      .sort((a, b) => a.avg - b.avg);
  })();

  // Sorted items for list-detail
  const sortedItems = currentList ? applySortKey(currentList.items, settings.sortKey) : [];

  // Apply price filter
  const displayedItems = listPriceFilter
    ? sortedItems.filter((item) => {
        const hint = item.priceHint || getPriceHint(item.name, item.price);
        if (!hint) return false;
        return listPriceFilter === "cheaper" ? hint.arrow === "down" : hint.arrow === "up";
      })
    : sortedItems;

  // Filtered lists for home
  const filteredLists = data.lists.filter(
    (l) =>
      !searchQuery ||
      l.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.market.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.items.some((i) => i.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // -- Style shortcuts --
  const inp = {
    display: "block", width: "100%", marginTop: 6, padding: "11px 13px",
    background: t.bg3, border: `1px solid ${t.bg4}`, borderRadius: 10,
    color: t.text, fontSize: fs, fontFamily: "inherit", outline: "none", boxSizing: "border-box",
  };
  const primaryBtn = {
    display: "block", width: "100%", padding: "13px", background: t.accent,
    color: t.accentText, border: "none", borderRadius: 10, fontSize: fs - 1,
    fontFamily: "inherit", fontWeight: "bold", letterSpacing: 1, cursor: "pointer",
  };
  const card = {
    background: t.bg2, border: `1px solid ${t.border}`,
    borderRadius: 14, padding: 16, marginBottom: 12,
  };
  const tabBtn = (active) => ({
    flex: 1, padding: "8px 4px", fontSize: fs - 4, letterSpacing: 0.5,
    cursor: "pointer", fontFamily: "inherit",
    border: `1px solid ${active ? t.accent : t.border}`,
    background: active ? t.accentBg : "transparent",
    color: active ? t.accent : t.text3, borderRadius: 8,
  });

  const navItems = [
    { key: "home",     icon: "🛒", label: "Listas" },
    { key: "analysis", icon: "📊", label: "Análise" },
    { key: "settings", icon: "⚙️", label: "Configurações" },
  ];

  // -- Hamburger position --
  const hPos = settings.hamburgerPos || "top-left";
  const hStyle = (() => {
    const MARGIN = 14;
    const base = { position: "fixed", zIndex: 400 };
    // Max-width container is 430px centered, so we clamp to its edges
    const left  = `max(${MARGIN}px, calc(50vw - 215px + ${MARGIN}px))`;
    const right = `max(${MARGIN}px, calc(50vw - 215px + ${MARGIN}px))`;
    const cx    = "calc(50vw - 19px)"; // centered (half of 38px button)
    const top   = `${MARGIN}px`;
    const bot   = `${MARGIN + 20}px`;
    switch (hPos) {
      case "top-left":    return { ...base, top, left };
      case "top-center":  return { ...base, top, left: cx };
      case "top-right":   return { ...base, top, right };
      case "bottom-left": return { ...base, bottom: bot, left };
      case "bottom-center": return { ...base, bottom: bot, left: cx };
      case "bottom-right":  return { ...base, bottom: bot, right };
      default:            return { ...base, top, left };
    }
  })();

  // -- TOP-LEVEL TOUCH HANDLERS (swipe) --
  return (
    <div
      style={{
        fontFamily: "'Georgia', serif",
        background: t.bg,
        height: "100vh",
        maxWidth: 430,
        margin: "0 auto",
        color: t.text,
        position: "relative",
        overflowX: "hidden",
        display: "flex",
        flexDirection: "column",
        fontSize: fs,
      }}
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >

      {/* -- TOAST -- */}
      {toast && (
        <div style={{
          position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)",
          background: t.accent, color: t.accentText, padding: "9px 22px",
          borderRadius: 20, fontFamily: "monospace", fontSize: fs - 2,
          zIndex: 1000, fontWeight: "bold", letterSpacing: 1,
          boxShadow: `0 4px 20px ${t.shadow}`, whiteSpace: "nowrap",
        }}>
          {toast}
        </div>
      )}

      {/* -- TAB BAR — rendered at top or bottom based on setting -- */}
      {(() => {
        const tabPos = settings.tabPosition || "bottom";
        if (view === "list-detail") return null;
        const isBottom = tabPos === "bottom";
        return (
          <div style={{
            flexShrink: 0,
            display: "flex",
            order: isBottom ? 99 : 0,
            borderTop: isBottom ? `1px solid ${t.border}` : "none",
            borderBottom: isBottom ? "none" : `1px solid ${t.border}`,
            background: t.bg2,
          }}>
            {navItems.map((item) => {
              const active = view === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => navigate(item.key)}
                  style={{
                    flex: 1, display: "flex", flexDirection: "column",
                    alignItems: "center", justifyContent: "center",
                    gap: 3, padding: "10px 4px",
                    background: "none", border: "none",
                    color: active ? t.accent : t.text3,
                    cursor: "pointer", fontFamily: "inherit",
                    borderTop: isBottom ? `2px solid ${active ? t.accent : "transparent"}` : "none",
                    borderBottom: isBottom ? "none" : `2px solid ${active ? t.accent : "transparent"}`,
                  }}
                >
                  <span style={{ fontSize: fs + 4 }}>{item.icon}</span>
                  <span style={{ fontSize: fs - 5, letterSpacing: 0.3 }}>{item.label}</span>
                </button>
              );
            })}
          </div>
        );
      })()}

      {/* -- HAMBURGER (optional floating button, configurable) -- */}
      {view !== "list-detail" && settings.showHamburger && (
        <button
          onClick={() => {}}
          style={{
            ...hStyle,
            background: t.bg2, border: `1px solid ${t.border}`,
            color: t.text2, width: 38, height: 38, borderRadius: 10,
            cursor: "pointer", fontSize: 17,
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: `0 2px 10px ${t.shadow}`,
            pointerEvents: "none", opacity: 0, // hidden — kept for layout compat
          }}
        >
          ☰
        </button>
      )}

      {/* ======================================================================
          H O M E
      ====================================================================== */}
      {view === "home" && (
        <div style={{ flex: 1, overflowY: "auto", paddingBottom: 40, paddingTop: 0 }}>
          {/* Header */}
          <div style={{
            padding: "14px 24px 18px", paddingTop: 20,
            background: `linear-gradient(160deg, ${t.bg2}, ${t.bg})`,
            borderBottom: `1px solid ${t.border}`,
          }}>
            <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
              {[
                { label: "Listas", value: (() => { const n = data.lists.filter((l) => monthKey(l.date) === monthKey(todayStr())).length; return n + (n === 1 ? " lista" : " listas"); })() },
                { label: "Este mês", value: fmt(data.lists.filter((l) => monthKey(l.date) === monthKey(todayStr())).reduce((s, l) => s + listTotal(l), 0)) },
                { label: "Produtos", value: (() => { const curMk = monthKey(todayStr()); const lists = data.lists.filter((l) => monthKey(l.date) === curMk); const names = new Set(lists.flatMap((l) => l.items.map((i) => i.name.toLowerCase()))); return names.size; })() },
              ].map((s) => (
                <div key={s.label} style={{ flex: 1, background: t.bg3, border: `1px solid ${t.border}`, borderRadius: 10, padding: "10px 8px" }}>
                  <div style={{ fontSize: fs - 6, color: t.text3, letterSpacing: 1 }}>{s.label.toUpperCase()}</div>
                  <div style={{ fontSize: fs, color: t.accent, marginTop: 2, fontWeight: "bold" }}>{s.value}</div>
                </div>
              ))}
            </div>
            <div style={{ position: "relative" }}>
              <input
                value={itemSearchQuery}
                onChange={(e) => handleItemSearch(e.target.value)}
                onFocus={() => itemSearchQuery.length >= 2 && setShowItemSuggestions(itemSearchSuggestions.length > 0)}
                placeholder="🔍 Buscar histórico de preço de item..."
                style={{ ...inp, marginTop: 0 }}
              />
              {showItemSuggestions && (
                <div style={{ position: "absolute", top: "100%", left: 0, right: 0, zIndex: 50, background: t.bg2, border: `1px solid ${t.border}`, borderRadius: 10, overflow: "hidden", boxShadow: `0 8px 24px ${t.shadow}`, marginTop: 4 }}>
                  {itemSearchSuggestions.map((s) => (
                    <div
                      key={s.name}
                      onClick={() => selectItemHistory(s.name)}
                      style={{ padding: "10px 14px", cursor: "pointer", borderBottom: `1px solid ${t.bg3}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}
                    >
                      <span style={{ fontSize: fs - 1, color: t.text }}>{s.name}</span>
                      <span style={{ fontSize: fs - 4, color: t.text3 }}>{s.count} registro{s.count !== 1 ? "s" : ""}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Item history result */}
            {itemSearchSelected && (() => {
              const { name, entries } = itemSearchSelected;
              const prices = entries.map((e) => e.price);
              const minP = Math.min(...prices);
              const maxP = Math.max(...prices);
              const avgP = prices.reduce((a, b) => a + b, 0) / prices.length;
              return (
                <div style={{ marginTop: 12, background: t.bg2, border: `1px solid ${t.accentBorder}`, borderRadius: 12, overflow: "hidden" }}>
                  {/* Header */}
                  <div style={{ padding: "12px 14px", borderBottom: `1px solid ${t.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontSize: fs, fontWeight: "bold", color: t.accent }}>{name}</div>
                      <div style={{ fontSize: fs - 4, color: t.text3, marginTop: 2 }}>{entries.length} registro{entries.length !== 1 ? "s" : ""}</div>
                    </div>
                    <button onClick={() => { setItemSearchSelected(null); setItemSearchQuery(""); }} style={{ background: t.bg3, border: "none", color: t.text3, width: 28, height: 28, borderRadius: 7, cursor: "pointer", fontSize: 14 }}>✕</button>
                  </div>
                  {/* Min / avg / max */}
                  <div style={{ display: "flex", borderBottom: `1px solid ${t.border}` }}>
                    {[["Mínimo", minP, t.down], ["Média", avgP, t.accent], ["Máximo", maxP, t.up]].map(([label, val, color]) => (
                      <div key={label} style={{ flex: 1, padding: "10px 8px", textAlign: "center", borderRight: label !== "Máximo" ? `1px solid ${t.border}` : "none" }}>
                        <div style={{ fontSize: fs - 5, color: t.text3, letterSpacing: 0.5 }}>{label.toUpperCase()}</div>
                        <div style={{ fontSize: fs - 1, fontWeight: "bold", color, marginTop: 3 }}>{fmt(val)}</div>
                      </div>
                    ))}
                  </div>
                  {/* Table header */}
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", padding: "7px 12px", background: t.bg3 }}>
                    {["Data", "Mercado", "Valor", "Diferença"].map((h) => (
                      <div key={h} style={{ fontSize: fs - 5, color: t.text3, fontWeight: "bold", letterSpacing: 0.5 }}>{h.toUpperCase()}</div>
                    ))}
                  </div>
                  {/* Rows — newest first, oldest has no diff */}
                  {entries.map((entry, idx) => {
                    const next = entries[idx + 1]; // older entry
                    let diffEl = <span style={{ color: t.text4 }}>—</span>;
                    if (next) {
                      const diff = entry.price - next.price;
                      const pct = Math.abs((diff / next.price) * 100).toFixed(1);
                      const isUp = diff > 0;
                      const color = isUp ? t.up : t.down;
                      diffEl = (
                        <span style={{ color, fontSize: fs - 3 }}>
                          {isUp ? "▲" : "▼"} {fmt(Math.abs(diff))} ({pct}%)
                        </span>
                      );
                    } else {
                      diffEl = <span style={{ fontSize: fs - 4, color: t.text4, fontStyle: "italic" }}>1ª compra</span>;
                    }
                    return (
                      <div key={idx} style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", padding: "9px 12px", borderTop: `1px solid ${t.bg3}`, alignItems: "center" }}>
                        <div style={{ fontSize: fs - 3, color: t.text2 }}>
                          {new Date(entry.date + "T12:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit" })}
                        </div>
                        <div style={{ fontSize: fs - 4, color: t.text3 }}>{entry.market || "—"}</div>
                        <div style={{ fontSize: fs - 2, fontWeight: "bold", color: t.text }}>{fmt(entry.price)}</div>
                        <div>{diffEl}</div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>

          {/* Inline new list form */}
          <div style={{ padding: "12px 24px 0" }}>
            {!showNewListForm ? (
              <button onClick={() => setShowNewListForm(true)} style={primaryBtn}>+ NOVA LISTA</button>
            ) : (
              <div style={{ background: t.bg2, border: `1px solid ${t.accentBorder}`, borderRadius: 14, padding: 16, marginBottom: 4 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                  <div style={{ fontSize: fs, fontWeight: "bold", color: t.accent }}>Nova Lista</div>
                  <button onClick={() => { setShowNewListForm(false); setNewListName(""); }} style={{ background: "none", border: "none", color: t.text3, cursor: "pointer", fontSize: fs + 2, padding: "0 4px" }}>✕</button>
                </div>

                <div style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: fs - 4, letterSpacing: 2, color: t.text3 }}>NOME DA LISTA</label>
                  <input
                    value={newListName}
                    onChange={(e) => setNewListName(e.target.value)}
                    placeholder="Ex: Compras de sexta"
                    style={{ ...inp, marginTop: 6 }}
                    onKeyDown={(e) => e.key === "Enter" && createList()}
                    autoFocus
                  />
                </div>

                <div style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: fs - 4, letterSpacing: 2, color: t.text3 }}>MERCADO</label>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 8, marginBottom: 8 }}>
                    {markets.map((m, idx) => (
                      <div key={idx} style={{ display: "flex", alignItems: "center", borderRadius: 20, overflow: "hidden", border: `1px solid ${newListMarket === m ? t.accent : t.border}`, background: newListMarket === m ? t.accentBg : t.bg3 }}>
                        {editingMarketIdx === idx ? (
                          <>
                            <input
                              value={editingMarketVal}
                              onChange={(e) => setEditingMarketVal(e.target.value)}
                              onKeyDown={(e) => { if (e.key === "Enter") saveMarketEdit(); if (e.key === "Escape") setEditingMarketIdx(null); }}
                              style={{ ...inp, marginTop: 0, border: "none", background: "transparent", padding: "6px 10px", fontSize: fs - 2, width: 100, outline: "none", color: t.text }}
                              autoFocus
                            />
                            <button onClick={saveMarketEdit} style={{ background: "none", border: "none", color: t.accent, padding: "6px 8px", cursor: "pointer", fontSize: fs - 2 }}>✓</button>
                            <button onClick={() => setEditingMarketIdx(null)} style={{ background: "none", border: "none", color: t.text3, padding: "6px 6px 6px 0", cursor: "pointer", fontSize: fs - 2 }}>✕</button>
                          </>
                        ) : (
                          <>
                            <button onClick={() => setNewListMarket(m)} style={{ background: "none", border: "none", padding: "6px 10px", fontSize: fs - 2, cursor: "pointer", color: newListMarket === m ? t.accent : t.text2, fontFamily: "inherit", fontWeight: newListMarket === m ? "bold" : "normal" }}>
                              🏪 {m}
                            </button>
                            <button onClick={() => { setEditingMarketIdx(idx); setEditingMarketVal(m); }} style={{ background: "none", border: "none", color: t.text4, padding: "6px 4px 6px 0", cursor: "pointer", fontSize: fs - 4 }}>✏️</button>
                            {markets.length > 1 && (
                              <button onClick={() => removeMarket(idx)} style={{ background: "none", border: "none", color: t.text4, padding: "6px 8px 6px 2px", cursor: "pointer", fontSize: fs - 4 }}>✕</button>
                            )}
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <input
                      value={newMarketName}
                      onChange={(e) => setNewMarketName(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && addMarket()}
                      placeholder="+ Novo mercado..."
                      style={{ ...inp, marginTop: 0, flex: 1, padding: "8px 12px", borderStyle: "dashed" }}
                    />
                    <button
                      onClick={addMarket}
                      disabled={!newMarketName.trim()}
                      style={{ background: newMarketName.trim() ? t.accent : t.bg4, color: newMarketName.trim() ? t.accentText : t.text4, border: "none", borderRadius: 10, padding: "9px 14px", cursor: newMarketName.trim() ? "pointer" : "default", fontFamily: "inherit", fontWeight: "bold", fontSize: fs, flexShrink: 0 }}
                    >+</button>
                  </div>
                </div>

                <button onClick={createList} style={primaryBtn}>CRIAR LISTA</button>
              </div>
            )}
          </div>

          <div style={{ padding: "14px 24px 0" }}>
            {filteredLists.length === 0 ? (
              <div style={{ textAlign: "center", padding: "50px 0", color: t.text4 }}>
                <div style={{ fontSize: 38 }}>🛒</div>
                <div style={{ marginTop: 10, fontSize: fs }}>Nenhuma lista encontrada</div>
              </div>
) : (() => {
              const now = new Date();
              const curMk = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;
              const currentLists = filteredLists.filter((l) => (l.date || "").startsWith(curMk));
              const historyLists = filteredLists.filter((l) => !(l.date || "").startsWith(curMk));

              // Group history by month
              const histGroups = {};
              historyLists.forEach((list) => {
                const mk = list.date ? list.date.substring(0, 7) : "0000-00";
                if (!histGroups[mk]) histGroups[mk] = [];
                histGroups[mk].push(list);
              });
              const histKeys = Object.keys(histGroups).sort((a, b) => b.localeCompare(a));

              const renderListCard = (list, idx, lists) => (
                          <div
                            key={list.id}
                            style={{ ...card, cursor: "pointer", margin: 0, borderRadius: 0, border: "none", borderBottom: idx < lists.length - 1 ? `1px solid ${t.bg3}` : "none" }}
                            onClick={() => { setActiveListId(list.id); setSearchQuery(""); setView("list-detail"); }}
                          >
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                              <div style={{ flex: 1, minWidth: 0 }}>
                                <div style={{ fontWeight: "bold", fontSize: fs + 1 }}>{list.name}</div>
                                <div style={{ fontSize: fs - 3, color: t.text3, marginTop: 2 }}>
                                  {list.market} · {new Date(list.date + "T12:00").toLocaleDateString("pt-BR")}
                                </div>
                              </div>
                              <div style={{ textAlign: "right", flexShrink: 0, marginLeft: 10 }}>
                                <div style={{ color: t.accent, fontWeight: "bold", fontSize: fs + 3 }}>{fmt(listTotal(list))}</div>
                                <div style={{ fontSize: fs - 4, color: t.text3 }}>{list.items.length} vol · {list.items.reduce((s,i)=>s+(parseInt(i.qty,10)||1),0)} itens</div>
                              </div>
                            </div>
                            {list.items.length > 0 && (
                              <div style={{ marginTop: 8, display: "flex", gap: 5, flexWrap: "wrap" }}>
                                {list.items.slice(0, 5).map((i) => (
                                  <span key={i.id} style={{ background: t.bg3, borderRadius: 6, padding: "2px 7px", fontSize: fs - 4, color: t.text3, textDecoration: i.checked ? "line-through" : "none" }}>
                                    {i.name}
                                  </span>
                                ))}
                                {list.items.length > 5 && <span style={{ fontSize: fs - 4, color: t.text4 }}>+{list.items.length - 5}</span>}
                              </div>
                            )}
                            <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
                              <button
                                onClick={(e) => { e.stopPropagation(); setDuplicateSource(list); setDuplicateZero(false); setDuplicateMarket(list.market); }}
                                style={{ background: t.accentBg, border: `1px solid ${t.accentBorder}`, color: t.accent, borderRadius: 8, padding: "4px 10px", fontSize: fs - 4, cursor: "pointer", fontFamily: "inherit" }}
                              >
                                ⧉ Duplicar
                              </button>
                              {confirmDeleteId === list.id ? (
                                <>
                                  <button
                                    onClick={(e) => { e.stopPropagation(); deleteList(list.id); setConfirmDeleteId(null); }}
                                    style={{ background: "#c0392b22", border: "1px solid #c0392b66", color: "#e74c3c", borderRadius: 8, padding: "4px 10px", fontSize: fs - 4, cursor: "pointer", fontFamily: "inherit", fontWeight: "bold" }}
                                  >
                                    ✕ Confirmar
                                  </button>
                                  <button
                                    onClick={(e) => { e.stopPropagation(); setConfirmDeleteId(null); }}
                                    style={{ background: "none", border: "none", color: t.text4, fontSize: fs - 4, cursor: "pointer", padding: "4px 0", fontFamily: "inherit" }}
                                  >
                                    Cancelar
                                  </button>
                                </>
                              ) : (
                                <button
                                  onClick={(e) => { e.stopPropagation(); setConfirmDeleteId(list.id); }}
                                  style={{ background: "none", border: "none", color: t.text4, fontSize: fs - 4, cursor: "pointer", padding: "4px 0", fontFamily: "inherit" }}
                                >
                                  ✕ Remover
                                </button>
                              )}
                            </div>
                          </div>
              );

              return (
                <>
                  {/* Current month lists */}
                  {currentLists.length === 0 && !searchQuery ? (
                    <div style={{ textAlign: "center", padding: "30px 0", color: t.text4, fontSize: fs - 1 }}>
                      Nenhuma lista este mês
                    </div>
                  ) : (
                    <div style={{ border: `1px solid ${t.accentBorder}`, borderRadius: 12, overflow: "hidden", marginBottom: 8 }}>
                      {currentLists.map((list, idx) => renderListCard(list, idx, currentLists))}
                    </div>
                  )}

                  {/* History — Meses anteriores */}
                  {historyLists.length > 0 && (
                    <div style={{ marginTop: 4 }}>
                      {/* Toggle button */}
                      <button
                        onClick={() => setShowHistory((v) => !v)}
                        style={{ width: "100%", padding: "12px", background: t.bg2, border: `1px solid ${t.border}`, borderRadius: showHistory ? "12px 12px 0 0" : 12, color: t.text3, fontSize: fs - 2, cursor: "pointer", fontFamily: "inherit", display: "flex", alignItems: "center", gap: 8, borderBottom: showHistory ? "none" : `1px solid ${t.border}` }}
                      >
                        <span>🗂️</span>
                        <span>Meses anteriores</span>
                        <span style={{ marginLeft: "auto", fontSize: fs - 3, transition: "transform 0.2s", display: "inline-block", transform: showHistory ? "rotate(180deg)" : "none" }}>▾</span>
                      </button>

                      {showHistory && (() => {
                        // Group by year first, then month
                        const byYear = {};
                        histKeys.forEach((mk) => {
                          const yr = mk.substring(0, 4);
                          if (!byYear[yr]) byYear[yr] = [];
                          byYear[yr].push(mk);
                        });
                        const years = Object.keys(byYear).sort((a, b) => b - a);

                        return (
                          <div style={{ border: `1px solid ${t.border}`, borderTop: "none", borderRadius: "0 0 12px 12px", overflow: "hidden" }}>
                            {years.map((yr, yi) => (
                              <div key={yr}>
                                {/* Year header */}
                                <div style={{ padding: "6px 14px", background: t.bg4 || t.bg3, borderTop: yi > 0 ? `1px solid ${t.border}` : "none" }}>
                                  <span style={{ fontSize: fs - 4, fontWeight: "bold", color: t.text3, letterSpacing: 1 }}>{yr}</span>
                                </div>
                                {/* Month rows */}
                                {byYear[yr].map((mk) => {
                                  const mo = mk.substring(5, 7);
                                  const monthName = mo && mo !== "00" ? MONTHS_FULL[parseInt(mo, 10) - 1] : "Data desconhecida";
                                  const lists = histGroups[mk];
                                  const groupTotal = lists.reduce((s, l) => s + listTotal(l), 0);
                                  const isMonthOpen = !!openHistoryMonths[mk];
                                  return (
                                    <div key={mk}>
                                      {/* Month header — tap to expand */}
                                      <div
                                        onClick={() => setOpenHistoryMonths((o) => ({ ...o, [mk]: !o[mk] }))}
                                        style={{ padding: "11px 14px", background: t.bg3, display: "flex", justifyContent: "space-between", alignItems: "center", borderTop: `1px solid ${t.border}`, cursor: "pointer" }}
                                      >
                                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                          <span style={{ fontSize: fs - 3, transition: "transform 0.15s", display: "inline-block", transform: isMonthOpen ? "rotate(90deg)" : "none", color: t.text3 }}>▶</span>
                                          <span style={{ fontSize: fs - 1, fontWeight: "bold", color: t.text2 }}>{monthName}</span>
                                        </div>
                                        <span style={{ fontSize: fs - 3, color: t.text3 }}>{lists.length} lista{lists.length !== 1 ? "s" : ""} · {fmt(groupTotal)}</span>
                                      </div>
                                      {/* Lists inside month */}
                                      {isMonthOpen && (
                                        <div style={{ borderTop: `1px solid ${t.bg3}` }}>
                                          {lists.map((list, idx) => renderListCard(list, idx, lists))}
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            ))}
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* ======================================================================
          L I S T   D E T A I L
      ====================================================================== */}
      {view === "list-detail" && currentList && (
        <div style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>

          {/* -- Fixed top section -- */}
          <div style={{ flexShrink: 0, background: t.bg2, borderBottom: `1px solid ${t.border}`, zIndex: 10 }}>

            {/* Compact top bar: [← Voltar]  [☰ title]  [⋮] */}
            <div style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "10px 12px", paddingTop: "calc(10px + env(safe-area-inset-top, 0px))",
              borderBottom: `1px solid ${t.bg3}`,
            }}>
              {/* Left: back button */}
              <button
                onClick={() => { setView("home"); setSearchQuery(""); setListMenuOpen(false); setListPriceFilter(null); }}
                style={{ background: "none", border: "none", color: t.accent, fontSize: fs, cursor: "pointer", padding: "4px 6px", fontFamily: "inherit", flexShrink: 0, display: "flex", alignItems: "center", gap: 4, borderRadius: 8 }}
              >
                ← Voltar
              </button>

              {/* Centre: list name (tap to edit) */}
              <div
                style={{ flex: 1, minWidth: 0, textAlign: "center", cursor: "pointer" }}
                onClick={() => { setEditListName(currentList.name); setEditListMarket(currentList.market); setEditingListHeader(true); }}
              >
                <div style={{ fontSize: fs - 1, fontWeight: "bold", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", color: t.text }}>
                  {currentList.name}
                </div>
                <div style={{ fontSize: fs - 4, color: t.text3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  ✏️ {currentList.market} · {new Date(currentList.date + "T12:00").toLocaleDateString("pt-BR")}
                </div>
              </div>

              {/* Right: sort/actions menu */}
              <div style={{ position: "relative", flexShrink: 0 }}>
                <button
                  onClick={() => setListMenuOpen((v) => !v)}
                  style={{ background: t.bg3, border: `1px solid ${t.border}`, color: t.text2, borderRadius: 8, padding: "5px 10px", cursor: "pointer", fontSize: fs + 2, fontFamily: "inherit", lineHeight: 1 }}
                  title="Ordenar e ações"
                >
                  ⋮
                </button>

                {/* Dropdown menu — anchored to right edge */}
                {listMenuOpen && (
                  <>
                    <div onClick={() => setListMenuOpen(false)} style={{ position: "fixed", inset: 0, zIndex: 98 }} />
                    <div style={{
                      position: "absolute", right: 0, top: "calc(100% + 6px)", zIndex: 99,
                      background: t.bg2, border: `1px solid ${t.border}`, borderRadius: 12,
                      minWidth: 230, boxShadow: `0 8px 32px rgba(0,0,0,0.5)`, overflow: "hidden",
                    }}>
                      <div style={{ padding: "10px 16px", fontSize: fs - 5, letterSpacing: 2, color: t.text3, borderBottom: `1px solid ${t.border}` }}>
                        ORDENAR POR
                      </div>
                      {SORT_OPTIONS.map((opt) => (
                        <button
                          key={opt.key}
                          onClick={() => { setSettings((s) => ({ ...s, sortKey: opt.key })); setListMenuOpen(false); }}
                          style={{
                            display: "flex", alignItems: "center", justifyContent: "space-between",
                            width: "100%", padding: "11px 16px",
                            background: settings.sortKey === opt.key ? t.accentBg : "none",
                            border: "none", borderBottom: `1px solid ${t.bg3}`,
                            color: settings.sortKey === opt.key ? t.accent : t.text,
                            cursor: "pointer", fontFamily: "inherit", fontSize: fs - 2, textAlign: "left",
                          }}
                        >
                          <span>{opt.label}</span>
                          {settings.sortKey === opt.key && <span>✓</span>}
                        </button>
                      ))}
                      <div style={{ padding: "10px 16px", fontSize: fs - 5, letterSpacing: 2, color: t.text3, borderBottom: `1px solid ${t.border}`, borderTop: `1px solid ${t.border}`, marginTop: 4 }}>
                        FILTRAR PREÇO
                      </div>
                      {[
                        { key: null,       label: "Todos os itens",       icon: "○" },
                        { key: "cheaper",  label: "Ficou mais barato",    icon: "▼", color: t.down },
                        { key: "pricier",  label: "Ficou mais caro",      icon: "▲", color: t.up   },
                      ].map(({ key, label, icon, color }) => {
                        const active = listPriceFilter === key;
                        return (
                          <button
                            key={String(key)}
                            onClick={() => { setListPriceFilter(key); setListMenuOpen(false); }}
                            style={{
                              display: "flex", alignItems: "center", gap: 10,
                              width: "100%", padding: "11px 16px",
                              background: active ? t.accentBg : "none",
                              border: "none", borderBottom: `1px solid ${t.bg3}`,
                              color: active ? t.accent : t.text,
                              cursor: "pointer", fontFamily: "inherit", fontSize: fs - 2, textAlign: "left",
                            }}
                          >
                            <span style={{ color: active ? t.accent : (color || t.text3), fontSize: fs - 2, width: 14 }}>{icon}</span>
                            <span style={{ flex: 1 }}>{label}</span>
                            {active && <span style={{ color: t.accent }}>✓</span>}
                          </button>
                        );
                      })}
                      <div style={{ padding: "10px 16px", fontSize: fs - 5, letterSpacing: 2, color: t.text3, borderBottom: `1px solid ${t.border}`, borderTop: `1px solid ${t.border}`, marginTop: 4 }}>
                        AÇÕES
                      </div>
                      <button
                        onClick={() => markAll(true)}
                        style={{ display: "block", width: "100%", padding: "11px 16px", background: "none", border: "none", borderBottom: `1px solid ${t.bg3}`, color: t.text, cursor: "pointer", fontFamily: "inherit", fontSize: fs - 2, textAlign: "left" }}
                      >
                        ✓ Marcar todos
                      </button>
                      <button
                        onClick={() => markAll(false)}
                        style={{ display: "block", width: "100%", padding: "11px 16px", background: "none", border: "none", color: t.text, cursor: "pointer", fontFamily: "inherit", fontSize: fs - 2, textAlign: "left" }}
                      >
                        ○ Desmarcar todos
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Total strip — compact single line */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 16px", background: t.bg }}>
              <div style={{ fontSize: fs - 4, color: t.text3 }}>
                {currentList.items.filter((i) => i.checked).length}/{currentList.items.length} marcados
              </div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
                <span style={{ fontSize: fs - 4, color: t.text3, letterSpacing: 1 }}>TOTAL</span>
                <span style={{ fontSize: fs + 6, color: t.accent, fontWeight: "bold", lineHeight: 1 }}>{fmt(listTotal(currentList))}</span>
              </div>
            </div>

            {/* Add item form */}
            <div style={{ padding: "10px 16px 12px", background: t.bg, borderBottom: `1px solid ${t.border}`, position: "relative" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 56px 70px", gap: 6, marginBottom: 8 }}>
                <div style={{ position: "relative" }}>
                  <input
                    value={newItem.name}
                    onChange={(e) => handleNameInput(e.target.value)}
                    placeholder="Produto"
                    style={{ ...inp, marginTop: 0 }}
                    onKeyDown={(e) => e.key === "Enter" && addItem()}
                  />
                  {showAutocomplete && (
                    <div style={{ position: "absolute", top: "100%", left: 0, right: 0, background: t.bg2, border: `1px solid ${t.border}`, borderRadius: 10, zIndex: 50, overflow: "hidden", boxShadow: `0 8px 24px ${t.shadow}` }}>
                      {autocomplete.map((ac) => {
                        const existingItem = currentList?.items.find((i) => i.name.toLowerCase() === ac.name.toLowerCase());
                        return (
                          <div key={ac.name} style={{ borderBottom: `1px solid ${t.border}` }}>
                            <div
                              onClick={() => pickAutocomplete(ac)}
                              style={{ padding: "10px 14px", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", background: existingItem ? t.accentBg : "transparent" }}
                            >
                              <div>
                                <span style={{ textTransform: "capitalize", fontSize: fs - 1, color: existingItem ? t.accent : t.text }}>{ac.name}</span>
                                {existingItem && (
                                  <span style={{ fontSize: fs - 5, color: t.accent, marginLeft: 8, background: t.accentBg, padding: "1px 6px", borderRadius: 4 }}>já na lista</span>
                                )}
                              </div>
                              <span style={{ color: t.accent, fontSize: fs - 2 }}>{fmt(ac.lastPrice)}</span>
                            </div>
                            {existingItem && (
                              <div
                                onClick={() => { setEditingItem({ ...existingItem, price: maskCurrency(String(Math.round(existingItem.price * 100))) }); setShowAutocomplete(false); setNewItem({ name: "", qty: "", price: "" }); }}
                                style={{ padding: "7px 14px", cursor: "pointer", background: t.accentBg, display: "flex", alignItems: "center", gap: 6 }}
                              >
                                <span style={{ fontSize: fs - 4, color: t.accent }}>✏️ Editar item existente ({existingItem.qty}x · {fmt(existingItem.price)})</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
                <input
                  type="number"
                  value={newItem.qty}
                  onChange={(e) => setNewItem((i) => ({ ...i, qty: e.target.value.replace(/[^0-9]/g, "") }))}
                  placeholder="Qtd"
                  style={{ ...inp, marginTop: 0 }}
                  min="1"
                  step="1"
                />
                <div style={{ position: "relative" }}>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={newItem.price}
                    onChange={(e) => setNewItem((i) => ({ ...i, price: maskCurrency(e.target.value) }))}
                    placeholder="0,00"
                    style={{ ...inp, marginTop: 0 }}
                    onKeyDown={(e) => e.key === "Enter" && addItem()}
                  />
                  {(() => {
                    const hint = getPriceHint(newItem.name, unmaskCurrency(newItem.price));
                    if (!hint) return null;
                    return (
                      <div style={{
                        position: "absolute", top: "50%", right: 6, transform: "translateY(-50%)",
                        fontSize: fs - 5, fontWeight: "bold", lineHeight: 1,
                        color: hint.arrow === "down" ? t.down : t.up,
                        display: "flex", flexDirection: "column", alignItems: "center", gap: 1,
                        pointerEvents: "none",
                      }}>
                        <span>{hint.arrow === "down" ? "▼" : "▲"}</span>
                        <span style={{ fontSize: fs - 7 }}>{hint.pct.toFixed(0)}%</span>
                      </div>
                    );
                  })()}
                </div>
              </div>
              <button onClick={addItem} style={{ ...primaryBtn, padding: "10px" }}>+ ADICIONAR</button>
            </div>
          </div>

          {/* -- Scrollable items -- */}
          <div style={{ flex: 1, overflowY: "auto", padding: "8px 16px 20px" }}>
            {/* Active filter badge */}
            {listPriceFilter && (
              <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 0 4px", marginBottom: 2 }}>
                <div style={{
                  display: "inline-flex", alignItems: "center", gap: 6,
                  background: listPriceFilter === "cheaper" ? t.downBg : t.upBg,
                  color: listPriceFilter === "cheaper" ? t.down : t.up,
                  borderRadius: 20, padding: "4px 12px", fontSize: fs - 4, fontWeight: "bold",
                }}>
                  {listPriceFilter === "cheaper" ? "▼ Mais baratos" : "▲ Mais caros"}
                  <span
                    onClick={() => setListPriceFilter(null)}
                    style={{ marginLeft: 4, cursor: "pointer", opacity: 0.7, fontSize: fs - 3 }}
                  >✕</span>
                </div>
              </div>
            )}
            {sortedItems.length === 0 && (
              <div style={{ textAlign: "center", padding: "40px 0", color: t.text4, fontSize: fs }}>
                Nenhum item ainda
              </div>
            )}
            {sortedItems.length > 0 && displayedItems.length === 0 && (
              <div style={{ textAlign: "center", padding: "40px 0", color: t.text4, fontSize: fs }}>
                Nenhum item com variação de preço encontrado
              </div>
            )}
            {displayedItems.map((item) => {
              const hint = item.priceHint || getPriceHint(item.name, item.price);
              return (
                <div key={item.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "11px 0", borderBottom: `1px solid ${t.bg3}` }}>
                  <div
                    onClick={() => toggleItem(item.id)}
                    style={{ width: 22, height: 22, borderRadius: 6, border: `2px solid ${item.checked ? t.accent : t.bg4}`, background: item.checked ? t.accent : "transparent", cursor: "pointer", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: fs - 3, color: t.accentText }}
                  >
                    {item.checked ? "✓" : ""}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: fs, textDecoration: item.checked ? "line-through" : "none", color: item.checked ? t.text4 : t.text, wordBreak: "break-word" }}>
                      {item.name}
                    </div>
                    <div style={{ fontSize: fs - 3, color: t.text3, display: "flex", alignItems: "center", gap: 5 }}>
                      <span>{item.qty}x {fmt(item.price)}</span>
                      {hint && (
                        <span style={{
                          color: hint.arrow === "down" ? t.down : t.up,
                          fontWeight: "bold", fontSize: fs - 4, lineHeight: 1,
                          display: "inline-flex", alignItems: "center", gap: 2,
                        }}>
                          {hint.arrow === "down" ? "▼" : "▲"}{hint.pct.toFixed(0)}%
                        </span>
                      )}
                    </div>
                  </div>
                  <div style={{ color: item.checked ? t.text4 : t.accent, fontWeight: "bold", fontSize: fs }}>
                    {fmt(item.qty * item.price)}
                  </div>
                  <button
                    onClick={() => setEditingItem({ ...item, price: maskCurrency(String(Math.round(item.price * 100))), qty: item.qty.toString() })}
                    style={{ background: "none", border: "none", color: t.text3, cursor: "pointer", fontSize: fs + 1, padding: "0 2px" }}
                  >
                    ✏️
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ======================================================================
          A N A L Y S I S
      ====================================================================== */}
      {view === "analysis" && (
        <div style={{ flex: 1, overflowY: "auto", paddingBottom: 40 }}>
          {/* Header */}
          <div style={{ padding: "16px 24px 16px", borderBottom: `1px solid ${t.border}`, background: t.bg2 }}>
            <h2 style={{ margin: "0 0 16px", fontWeight: "normal", fontSize: fs + 8 }}>Análise</h2>
            <div style={{ display: "flex", gap: 7 }}>
              {[["annual", "📅 Anual"], ["monthly", "🗓 Mensal"], ["markets", "🏪 Mercados"]].map(([k, l]) => (
                <button key={k} onClick={() => setAnalysisTab(k)} style={tabBtn(analysisTab === k)}>{l}</button>
              ))}
            </div>
          </div>

          <div style={{ padding: "16px 24px" }}>

            {/* -- ANNUAL ------------------------------------------- */}
            {analysisTab === "annual" && (
              <div>
                <div style={{ display: "flex", gap: 7, marginBottom: 18 }}>
                  {[["hbars", "↔ Horizontal"], ["numbers", "🔢 Números"]].map(([k, l]) => (
                    <button key={k} onClick={() => setChartMode(k)} style={tabBtn(chartMode === k)}>{l}</button>
                  ))}
                </div>

                {annualYears.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "60px 0", color: t.text4, fontSize: fs }}>Sem dados ainda</div>
                ) : annualYears.map((yr) => (
                  <div key={yr.year} style={card}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                      <div style={{ fontSize: fs + 2, color: t.text2, fontWeight: "bold" }}>{yr.year}</div>
                      <div style={{ color: t.accent, fontWeight: "bold", fontSize: fs + 2 }}>{fmt(yr.total)}</div>
                    </div>

                    {chartMode === "bars" && (
                      <VerticalBars data={yr.months} t={t} fs={fs} />
                    )}
                    {chartMode === "hbars" && (
                      <HorizontalBars data={yr.months.filter((m) => m.value > 0)} t={t} fs={fs} />
                    )}
                    {chartMode === "numbers" && (
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                        {yr.months.map((m) => (
                          <div key={m.key} style={{ background: t.bg3, borderRadius: 8, padding: "8px 10px", opacity: m.value > 0 ? 1 : 0.35 }}>
                            <div style={{ fontSize: fs - 4, color: t.text3 }}>{m.label}</div>
                            <div style={{ fontSize: fs - 1, color: m.value > 0 ? t.accent : t.text4, fontWeight: "bold", marginTop: 2 }}>
                              {m.value > 0 ? fmt(m.value) : "--"}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* -- MONTHLY ------------------------------------------ */}
            {analysisTab === "monthly" && (
              <div>
                {/* Month navigator */}
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                  <button
                    onClick={() => {
                      const idx = allMonthKeys.indexOf(safeMonth);
                      if (idx > 0) setAnalysisMonth(allMonthKeys[idx - 1]);
                    }}
                    disabled={allMonthKeys.indexOf(safeMonth) <= 0}
                    style={{ background: t.bg3, border: `1px solid ${t.border}`, color: t.text2, borderRadius: 8, padding: "8px 14px", cursor: "pointer", fontSize: fs + 2, opacity: allMonthKeys.indexOf(safeMonth) <= 0 ? 0.3 : 1 }}
                  >‹</button>
                  <div style={{ flex: 1, textAlign: "center", fontSize: fs + 1, color: t.text, fontWeight: "bold" }}>
                    {monthLabelFull(safeMonth)}
                  </div>
                  <button
                    onClick={() => {
                      const idx = allMonthKeys.indexOf(safeMonth);
                      if (idx < allMonthKeys.length - 1) setAnalysisMonth(allMonthKeys[idx + 1]);
                    }}
                    disabled={allMonthKeys.indexOf(safeMonth) >= allMonthKeys.length - 1}
                    style={{ background: t.bg3, border: `1px solid ${t.border}`, color: t.text2, borderRadius: 8, padding: "8px 14px", cursor: "pointer", fontSize: fs + 2, opacity: allMonthKeys.indexOf(safeMonth) >= allMonthKeys.length - 1 ? 0.3 : 1 }}
                  >›</button>
                </div>

                {/* View toggle */}
                <div style={{ display: "flex", gap: 7, marginBottom: 16 }}>
                  {[["bars", "📊 Gráfico"], ["numbers", "🔢 Números"]].map(([k, l]) => (
                    <button key={k} onClick={() => setChartMode(k)} style={tabBtn(chartMode === k)}>{l}</button>
                  ))}
                </div>

                {selectedMonthLists.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "40px 0", color: t.text4, fontSize: fs }}>
                    Sem listas neste mês
                  </div>
                ) : (
                  <>
                    {/* Summary card */}
                    <div style={{ ...card, background: t.accentBg, border: `1px solid ${t.accentBorder}` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                        <div>
                          <div style={{ fontSize: fs - 4, color: t.accent, letterSpacing: 2 }}>TOTAL DO MÊS</div>
                          <div style={{ fontSize: fs + 10, color: t.accent, fontWeight: "bold", lineHeight: 1.1 }}>
                            {fmt(selectedMonthLists.reduce((s, l) => s + listTotal(l), 0))}
                          </div>
                          <div style={{ fontSize: fs - 3, color: t.text3, marginTop: 4 }}>
                            {selectedMonthLists.length} lista{selectedMonthLists.length !== 1 ? "s" : ""}
                          </div>
                        </div>

                        {/* vs prev month */}
                        {prevMonthLists.length > 0 && (() => {
                          const cur = selectedMonthLists.reduce((s, l) => s + listTotal(l), 0);
                          const prev = prevMonthLists.reduce((s, l) => s + listTotal(l), 0);
                          const diff = ((cur - prev) / prev) * 100;
                          return (
                            <div style={{ textAlign: "right" }}>
                              <div style={{ fontSize: fs - 4, color: t.text3 }}>vs {monthLabel(prevMonthKey)}</div>
                              <div style={{ fontSize: fs + 3, color: diff > 0 ? t.up : t.down, fontWeight: "bold" }}>
                                {diff > 0 ? "↑" : "↓"} {Math.abs(diff).toFixed(1)}%
                              </div>
                              <div style={{ fontSize: fs - 4, color: t.text3 }}>{fmt(prev)}</div>
                            </div>
                          );
                        })()}
                      </div>
                    </div>

                    {/* Lists of the month */}
                    {chartMode === "bars" ? (
                      <div style={card}>
                        <div style={{ fontSize: fs - 4, letterSpacing: 2, color: t.text3, marginBottom: 14 }}>LISTAS DO MÊS</div>
                        <VerticalBars
                          data={selectedMonthLists.map((l) => ({ label: l.name.slice(0, 10), value: listTotal(l) }))}
                          t={t} fs={fs}
                        />
                      </div>
                    ) : (
                      selectedMonthLists.map((l) => (
                        <div
                          key={l.id}
                          style={{ ...card, cursor: "pointer" }}
                          onClick={() => { setActiveListId(l.id); setView("list-detail"); }}
                        >
                          <div style={{ display: "flex", justifyContent: "space-between" }}>
                            <div>
                              <div style={{ fontSize: fs, fontWeight: "bold" }}>{l.name}</div>
                              <div style={{ fontSize: fs - 3, color: t.text3 }}>
                                {l.market} · {new Date(l.date + "T12:00").toLocaleDateString("pt-BR")}
                              </div>
                              <div style={{ fontSize: fs - 3, color: t.text3, marginTop: 2 }}>{l.items.length} itens</div>
                            </div>
                            <div style={{ color: t.accent, fontWeight: "bold", fontSize: fs + 2, flexShrink: 0, marginLeft: 10 }}>
                              {fmt(listTotal(l))}
                            </div>
                          </div>
                        </div>
                      ))
                    )}

                    {/* Product price comparison */}
                    {productComparison.length > 0 && (
                      <div style={card}>
                        <div style={{ fontSize: fs - 4, letterSpacing: 2, color: t.text3, marginBottom: 14 }}>
                          COMPARAÇÃO COM {monthLabel(prevMonthKey).toUpperCase()}
                        </div>
                        {productComparison.slice(0, 12).map((p) => (
                          <div key={p.name} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 0", borderBottom: `1px solid ${t.bg3}` }}>
                            <div style={{ textTransform: "capitalize", fontSize: fs - 1, flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                              {p.name}
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0, marginLeft: 8 }}>
                              <span style={{ fontSize: fs - 3, color: t.text3 }}>{fmt(p.prevPrice)}</span>
                              <span style={{
                                fontSize: fs - 4, padding: "2px 7px", borderRadius: 8,
                                background: p.diff > 0 ? t.upBg : t.downBg,
                                color: p.diff > 0 ? t.up : t.down, fontWeight: "bold",
                              }}>
                                {p.diff > 0 ? "↑" : "↓"} {Math.abs(p.diff).toFixed(1)}%
                              </span>
                              <span style={{ fontSize: fs - 1, color: t.accent, fontWeight: "bold" }}>{fmt(p.curPrice)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            {/* -- MARKETS ------------------------------------------ */}
            {analysisTab === "markets" && (
              <div>
                <div style={{ display: "flex", gap: 7, marginBottom: 18 }}>
                  {[["hbars", "📊 Gráfico"], ["numbers", "🔢 Números"]].map(([k, l]) => (
                    <button key={k} onClick={() => setChartMode(k)} style={tabBtn(chartMode === k)}>{l}</button>
                  ))}
                </div>

                {dashMarkets.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "60px 0", color: t.text4, fontSize: fs }}>Sem dados ainda</div>
                ) : (
                  <>
                    <div style={{ background: t.accentBg, border: `1px solid ${t.accentBorder}`, borderRadius: 12, padding: 16, marginBottom: 14 }}>
                      <div style={{ fontSize: fs - 4, color: t.accent, letterSpacing: 2 }}>MAIS ECONÔMICO</div>
                      <div style={{ fontSize: fs + 5, marginTop: 4 }}>🏆 {dashMarkets[0]?.market}</div>
                      <div style={{ fontSize: fs - 2, color: t.text3, marginTop: 2 }}>Média: {fmt(dashMarkets[0]?.avg)}/compra</div>
                    </div>

                    {chartMode === "hbars" ? (
                      <div style={card}>
                        <HorizontalBars data={dashMarkets.map((m) => ({ label: m.market, value: m.avg }))} t={t} fs={fs} />
                      </div>
                    ) : (
                      dashMarkets.map((m, i) => (
                        <div key={m.market} style={{ ...card, display: "flex", alignItems: "center", gap: 12 }}>
                          <div style={{ width: 28, height: 28, borderRadius: 8, background: i === 0 ? t.accentBg : t.bg3, color: i === 0 ? t.accent : t.text3, display: "flex", alignItems: "center", justifyContent: "center", fontSize: fs - 2, fontWeight: "bold" }}>
                            {i + 1}º
                          </div>
                          <div style={{ flex: 1 }}>
                            <div style={{ fontSize: fs }}>{m.market}</div>
                            <div style={{ fontSize: fs - 3, color: t.text3 }}>{m.count} compra{m.count !== 1 ? "s" : ""}</div>
                          </div>
                          <div style={{ textAlign: "right" }}>
                            <div style={{ color: t.accent, fontSize: fs - 1 }}>{fmt(m.avg)}/compra</div>
                            <div style={{ fontSize: fs - 3, color: t.text3 }}>Total: {fmt(m.total)}</div>
                          </div>
                        </div>
                      ))
                    )}
                  </>
                )}
              </div>
            )}

          </div>
        </div>
      )}

      {/* ======================================================================
          S E T T I N G S
      ====================================================================== */}
      {view === "settings" && (() => {
        // Accordion helper
        const toggle = (key) => setSettingsOpen((o) => o === key ? null : key);
        const isOpen = (key) => settingsOpen === key;

        const AccordionHeader = ({ skey, icon, title, subtitle }) => (
          <div
            onClick={() => toggle(skey)}
            style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "15px 16px", cursor: "pointer",
              borderBottom: isOpen(skey) ? `1px solid ${t.border}` : "none",
            }}
          >
            <span style={{ fontSize: fs + 2 }}>{icon}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: fs - 1, fontWeight: "bold", color: t.text }}>{title}</div>
              {subtitle && <div style={{ fontSize: fs - 4, color: t.text3, marginTop: 2 }}>{subtitle}</div>}
            </div>
            <span style={{ color: t.text3, fontSize: fs - 2, transition: "transform 0.2s", display: "inline-block", transform: isOpen(skey) ? "rotate(180deg)" : "none" }}>▾</span>
          </div>
        );

        const acCard = { ...card, padding: 0, overflow: "visible", marginBottom: 10 };
        const body = { padding: "14px 16px 16px" };

        return (
          <div style={{ flex: 1, overflowY: "auto", padding: "16px 16px 40px" }}>
            <h2 style={{ margin: "0 0 20px", fontWeight: "normal", fontSize: fs + 8, paddingLeft: 8 }}>Configurações</h2>

            {/* 1 — NAVEGAÇÃO */}
            <div style={acCard}>
              <AccordionHeader skey="nav" icon="👆" title="Navegação"
                subtitle={`Botão voltar: ${{ confirm: "perguntar", minimize: "minimizar", nothing: "nada" }[settings.backBehavior || "confirm"]}`}
              />
              {isOpen("nav") && (
                <div style={body}>
                  {/* Back button behavior */}
                  <div style={{ fontSize: fs - 4, letterSpacing: 1, color: t.text3, marginBottom: 10 }}>BOTÃO VOLTAR (na tela inicial)</div>
                  {[
                    { key: "confirm",  label: "Perguntar antes de sair", desc: "Exibe confirmação antes de fechar o app" },
                    { key: "minimize", label: "Minimizar o app",          desc: "Vai para segundo plano sem perguntar" },
                    { key: "nothing",  label: "Fazer nada",           desc: "Botão voltar sem efeito na tela inicial" },
                  ].map(({ key, label, desc }) => {
                    const active = (settings.backBehavior || "confirm") === key;
                    return (
                      <button key={key}
                        onClick={() => setSettings((s) => ({ ...s, backBehavior: key }))}
                        style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "10px 12px", marginBottom: 8, background: active ? t.accentBg : t.bg3, border: `1px solid ${active ? t.accent : t.border}`, borderRadius: 10, cursor: "pointer", textAlign: "left" }}
                      >
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: fs - 2, color: active ? t.accent : t.text, fontWeight: active ? "bold" : "normal" }}>{label}</div>
                          <div style={{ fontSize: fs - 5, color: t.text3, marginTop: 2 }}>{desc}</div>
                        </div>
                        {active && <span style={{ color: t.accent }}>✓</span>}
                      </button>
                    );
                  })}

                  {/* Tab bar position */}
                  <div style={{ fontSize: fs - 4, letterSpacing: 1, color: t.text3, marginBottom: 10, marginTop: 16 }}>POSIÇÃO DA BARRA DE NAVEGAÇÃO</div>
                  <div style={{ display: "flex", gap: 8 }}>
                    {[
                      { key: "top",    label: "⬆️ Acima",  desc: "Topo da tela" },
                      { key: "bottom", label: "⬇️ Abaixo", desc: "Base da tela" },
                    ].map(({ key, label, desc }) => {
                      const active = (settings.tabPosition || "bottom") === key;
                      return (
                        <button key={key}
                          onClick={() => setSettings((s) => ({ ...s, tabPosition: key }))}
                          style={{ flex: 1, padding: "10px 8px", background: active ? t.accentBg : t.bg3, border: `1px solid ${active ? t.accent : t.border}`, borderRadius: 10, cursor: "pointer", textAlign: "center" }}
                        >
                          <div style={{ fontSize: fs, marginBottom: 2, color: active ? t.accent : t.text }}>{label}</div>
                          <div style={{ fontSize: fs - 5, color: active ? t.accent : t.text3 }}>{desc}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* 2 — APARÊNCIA */}
            <div style={acCard}>
              <AccordionHeader skey="theme" icon="🎨" title="Aparência"
                subtitle={`Paleta: ${allPalettes[settings.paletteKey]?.name || "Dourado"} · ${settings.paletteMode === "dark" ? "Escuro" : "Claro"}`}
              />
              {isOpen("theme") && (
                <div style={body}>
                  {/* Paleta */}
                  <div style={{ border: `1px solid ${t.border}`, borderRadius: 10, overflow: "hidden", marginBottom: 4 }}>
                    <div style={{ padding: "12px 12px 14px", background: t.bg2 }}>
                      {/* Light/dark toggle */}
                      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
                        {[["dark", "🌙 Escuro"], ["light", "☀️ Claro"]].map(([k, l]) => (
                          <button key={k} onClick={() => setSettings((s) => ({ ...s, paletteMode: k, themeSource: "palette" }))}
                            style={{ flex: 1, padding: "8px 4px", fontSize: fs - 3, border: `1px solid ${settings.paletteMode === k ? t.accent : t.border}`, background: settings.paletteMode === k ? t.accentBg : t.bg3, color: settings.paletteMode === k ? t.accent : t.text2, borderRadius: 8, cursor: "pointer", fontFamily: "inherit" }}
                          >{l}</button>
                        ))}
                      </div>
                      {/* Palettes */}
                      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                        {Object.entries(allPalettes).map(([key, pal]) => {
                          const active = settings.themeSource === "palette" && settings.paletteKey === key;
                          const isCustom = key.startsWith("custom_");
                          const desc = { dourado: "Clássica e elegante", nord: "Ártico e limpa", gruvbox: "Retrô e quente", rosePine: "Suave e floral", catppuccin: "Pastel techno", meiaNoite: "OLED · preto absoluto", papel: "Tinta sobre papel" };
                          return (
                            <div key={key} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                              <button onClick={() => setSettings((s) => ({ ...s, paletteKey: key, themeSource: "palette" }))}
                                style={{ flex: 1, display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: active ? t.accentBg : t.bg3, border: `1px solid ${active ? t.accent : t.border}`, borderRadius: 10, cursor: "pointer", textAlign: "left" }}
                              >
                                <div style={{ display: "flex", gap: 2, flexShrink: 0 }}>
                                  {[pal.dark.bg, pal.dark.accent].map((c, i) => <div key={i} style={{ width: 10, height: 26, borderRadius: i === 0 ? "3px 0 0 3px" : 0, background: c }} />)}
                                  <div style={{ width: 1, background: t.border }} />
                                  {[pal.light.bg, pal.light.accent].map((c, i) => <div key={i} style={{ width: 10, height: 26, borderRadius: i === 1 ? "0 3px 3px 0" : 0, background: c }} />)}
                                </div>
                                <div style={{ flex: 1 }}>
                                  <div style={{ fontSize: fs - 2, color: active ? t.accent : t.text, fontWeight: active ? "bold" : "normal" }}>
                                    {pal.name}{isCustom && <span style={{ fontSize: fs - 6, color: t.accent, marginLeft: 5, background: t.accentBg, padding: "1px 5px", borderRadius: 4 }}>custom</span>}
                                  </div>
                                  <div style={{ fontSize: fs - 5, color: t.text3 }}>{desc[key] || "Tema importado"}</div>
                                </div>
                                {active && <span style={{ color: t.accent }}>✓</span>}
                              </button>
                              {isCustom && (
                                <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                                  <button
                                    onClick={() => {
                                      const p = pal.dark;
                                      // Reverse-engineer the 4 key colors from saved palette
                                      setCustomPaletteEditor({
                                        name: pal.name,
                                        darkBg: p.bg,
                                        darkAccent: p.accent,
                                        lightBg: pal.light.bg,
                                        lightAccent: pal.light.accent,
                                        editKey: key,
                                      });
                                    }}
                                    style={{ background: t.accentBg, border: `1px solid ${t.accentBorder}`, color: t.accent, borderRadius: 8, padding: "7px 9px", cursor: "pointer", fontSize: fs - 3, flexShrink: 0 }}
                                  >✏️</button>
                                  {confirmDeletePaletteKey === key ? (
                                    <>
                                      <button
                                        onClick={() => { removeCustomTheme(key); setConfirmDeletePaletteKey(null); }}
                                        style={{ background: t.upBg, border: `1px solid ${t.up}66`, color: t.up, borderRadius: 8, padding: "7px 9px", cursor: "pointer", fontSize: fs - 3, fontWeight: "bold", flexShrink: 0 }}
                                      >✕ OK</button>
                                      <button
                                        onClick={() => setConfirmDeletePaletteKey(null)}
                                        style={{ background: t.bg3, border: `1px solid ${t.border}`, color: t.text3, borderRadius: 8, padding: "7px 9px", cursor: "pointer", fontSize: fs - 3, flexShrink: 0 }}
                                      >Não</button>
                                    </>
                                  ) : (
                                    <button
                                      onClick={() => setConfirmDeletePaletteKey(key)}
                                      style={{ background: t.upBg, border: `1px solid ${t.up}33`, color: t.up, borderRadius: 8, padding: "7px 9px", cursor: "pointer", fontSize: fs - 3, flexShrink: 0 }}
                                    >✕</button>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })}
                        {/* Add custom palette button */}
                        <button
                          onClick={() => setCustomPaletteEditor({ name: "Minha Paleta", darkBg: "#1e1e2e", darkAccent: "#88c0d0", lightBg: "#eceff4", lightAccent: "#5e81ac", editKey: null })}
                          style={{ width: "100%", padding: "10px 12px", background: t.bg3, border: `1px dashed ${t.border}`, borderRadius: 10, color: t.text3, fontSize: fs - 2, cursor: "pointer", fontFamily: "inherit", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
                        >
                          <span>🎨</span> Criar paleta personalizada
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 3 — FONTE */}
            <div style={acCard}>
              <AccordionHeader skey="font" icon="🔤" title="Tamanho da fonte" subtitle={`${fs}px · Toque para ajustar`} />
              {isOpen("font") && (
                <div style={body}>
                  <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 14 }}>
                    <button onClick={() => setSettings((s) => ({ ...s, fontSize: Math.max(11, (s.fontSize || 15) - 1) }))}
                      style={{ background: t.bg3, border: `1px solid ${t.border}`, color: t.text, width: 38, height: 38, borderRadius: 8, cursor: "pointer", fontSize: 20, fontFamily: "inherit", flexShrink: 0 }}>-</button>
                    <div style={{ flex: 1, textAlign: "center" }}>
                      <div style={{ fontSize: fs + 4, color: t.accent, fontWeight: "bold" }}>{fs}px</div>
                      <div style={{ fontSize: fs, color: t.text3, marginTop: 4 }}>Texto de exemplo</div>
                    </div>
                    <button onClick={() => setSettings((s) => ({ ...s, fontSize: Math.min(22, (s.fontSize || 15) + 1) }))}
                      style={{ background: t.bg3, border: `1px solid ${t.border}`, color: t.text, width: 38, height: 38, borderRadius: 8, cursor: "pointer", fontSize: 20, fontFamily: "inherit", flexShrink: 0 }}>+</button>
                  </div>
                  <input type="range" min={11} max={22} value={fs}
                    onChange={(e) => setSettings((s) => ({ ...s, fontSize: Number(e.target.value) }))}
                    style={{ width: "100%", accentColor: t.accent }} />
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: fs - 5, color: t.text4, marginTop: 4 }}>
                    <span>Menor (11)</span><span>Maior (22)</span>
                  </div>
                </div>
              )}
            </div>

            {/* 4 — DADOS */}
            <div style={acCard}>
              <AccordionHeader skey="data" icon="💾" title="Dados" subtitle="Exportar, importar ou apagar" />
              {isOpen("data") && (
                <div style={body}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    <button onClick={exportData} style={primaryBtn}>💾 SALVAR BACKUP AGORA</button>
                    <button
                      onClick={() => setBackupManager({ backups: getBackupIndex() })}
                      style={{ padding: "12px", background: t.bg3, color: t.text2, border: `1px solid ${t.border}`, borderRadius: 10, fontSize: fs - 1, fontFamily: "inherit", fontWeight: "bold", letterSpacing: 1, cursor: "pointer" }}>
                      📂 VER E RESTAURAR BACKUPS
                    </button>
                    <div style={{ fontSize: fs - 3, color: t.text3, lineHeight: 1.6 }}>
                      Backups ficam salvos no armazenamento interno do app.
                    </div>

                    <div style={{ height: 1, background: t.border, margin: "4px 0" }} />

                    <button
                      onClick={() => setConfirmModal({
                        title: "⚠️ Apagar tudo?",
                        message: "Isso apagará TODAS as listas e o histórico de preços permanentemente. Esta ação não pode ser desfeita.",
                        onConfirm: () => { setData({ lists: [], priceHistory: {} }); showToast("Todos os dados apagados."); },
                      })}
                      style={{ padding: "11px", background: t.upBg, color: t.up, border: `1px solid ${t.up}33`, borderRadius: 10, fontSize: fs - 2, fontFamily: "inherit", cursor: "pointer", width: "100%" }}
                    >
                      🗑 Apagar todos os dados
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Sobre o app link */}
            <button
              onClick={() => setView("about")}
              style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "14px 16px", background: t.bg2, border: `1px solid ${t.border}`, borderRadius: 12, color: t.text2, fontSize: fs - 1, cursor: "pointer", fontFamily: "inherit", marginTop: 4 }}
            >
              <span style={{ fontSize: fs + 2 }}>ℹ️</span>
              <span>Sobre o app</span>
              <span style={{ marginLeft: "auto", color: t.text4 }}>›</span>
            </button>

          </div>
        );
      })()}

      {/* ── ABOUT VIEW ── */}
      {view === "about" && (
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 16px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 28 }}>
            <button
              onClick={() => setView("settings")}
              style={{ background: "none", border: "none", color: t.accent, fontSize: fs, cursor: "pointer", padding: "4px 6px", fontFamily: "inherit" }}
            >← Voltar</button>
          </div>

          {/* App icon + name */}
          <div style={{ textAlign: "center", marginBottom: 32 }}>
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAmFElEQVR42u2deaym113fP79znudd7j5zZ9/H4xnbsR2vsYMxThwUZyEUhMQeStWCCn+gilIVhCq1pUKthET/KFBaBGoVUUFFk6gBQkJCFifEcePYju3MeOLx2LPemTvLXd/tec759Y9znuV9750kMMEvrfxK13P93nd5nrP8lu/3+/sd+ZO/+jnlzcfYHubNIXhzAt6cgDcf43sk/69dsNT+C4q+OQHlWAz9olL7X9nsdd96oHXo/wVEyNWh6sJzYjBiEQUVrb5Lh+aIoTkb+XRBRi5RR75d/v5OgDFhUDauT8EAyuazIPH+lBvcazGWAqKKiuDVoS5jtjFFI5kAhCzr0s3Xya3QII2TLmj5zZvNRPW8KqAKEiZQiwlRBTWEmfUUc6si4XI17D314b1GxjEBqpikgTEW8PGmBdEw/MYkSDG+Wq026jcyNEnF5AioR1WxONRA5nvMyiTH5u5lKy0a+QDUkeUDVrLrnOq8zmJqScQAFhED6sPgxdGJlxDWu3hQ8AoeH0yZ+nAtYuLf0/i8A+fxqjWDV3ymB/xNbZLkpoyxGoQEJSuXrVEDIjhRLILUdrSioIpXAWPKURGhtmoNgkdEURVy32M2szwwdw/tCyeRtQXylSXEK82ZSeYb02wV4ZmlRS5u30EDB/g40BriDDWIepCwm1AbJhmPikcB4+NCMg7BhBWu4f0OLT8zDLog2Di58u3b1e+8DyjWsMGoVsZHBIOAVqseCTekKCbaoGCCPB6PqkNxGCUMhDo8CdLr8papB2ieeRq/fomXX13kI8dPseo933/rbh655xjGTnHH6irnbEZv63bIM4J1FIwkgMELWAxGDRodlEhxzYIYg8EEUxRNjjGC94oxgnobJtQXq1/jJI/JByhxtUOYAExcHeE6JRpxweO9r2w/CuJK8yxOmTQt2skESo6Jnyfq8EZoJVPM5BkyuMbSiuM3n3qes/OzbN26ld9+9TyH9+9jz+4ZWo1Jdl/zZNu30DJxRwmotagIWb/Diu+SG4dRgzEWVTBiwrIxNnquaJZMmAgRj4gNRlY9RiQunDzYMAzgxrMDJFjcymnFVe3xuHyAaj/6gZQ0aSGSYoyh8AA5jh06yV1TdyKD5RDVeB+8mkbbaoVs6QRps8mVzgLX5rfwjkfvZtvULCfPvsa56T3sUQ9JgweO3EnSnEc1j9GNR0RQDDZZ49Q3/pKXDhzGNluIV8QKqiba/wHOD/DqQRNI0pq702h+6mGvUHrkcUVBXj3Wa+nExBicduhnfVqNbczPPshM+wiNZB6btkGbcRUZjE3prq2y9dLnSc99Bnd9AU3aOHXRVoMRG6OtBJc0OLRrB+/tGk7lFl3rceuB+7h9xy781ZcR28Bf/jq5yyAGMAbBF6lmkjJ1ZRkrR9n98A8w2TCYxOJVcC7H+w7OrdLLzrO8epyV3jkQR2KmgjMHEIMv/IFGMxod+hgmIGxF5zPAYo0hy1dppFvYv+8JZifvRbMJVtc7XL+yRGewRja4HqM+D7bB4Po5Hp2+gmYDfHMqmCxJAAuYcHPRyObekzZb/PQ9d/FiupM8aXMshelrL+Ik+h2xaGpAQyjqg3cHBIdhbuscJ7/8BZ5f3sWRfduDGcJgRGg0GkxPzTO/9Q4O7Hw3K92TXF36HOu9kxhJQ3QnxPAafJGLxLD3DZ8ACQYyrFKBbrbE/PT93LL3R+j227z88knOLZxgrXuF/mCV3FNuY7zSV5jtXuL9D+2CQRZMhVRRhcHF3R0mwaiQiZB0r/KA70FmcNeWyVQQ2wCfl/6HwlyohrAWJXee5tQcpvM8H//cH3DvsVtoT06S2CQMowgiKVOtOfbsPMptt97PwR3/hCvLn2Xx+idQYxA1VYKCvSnb/53ZAeLxVhgM1ti59bs5sONHOXd+keOnPs3lpddA+liTIlZIU4lJTrj+QS9j79YZGsaT5wNoNEvvLlLkDlIlUtEMOCyusx5u3qbBCTpPmS2JiRMoZbIUcguFtMGt8w2SlQGSWBrNBknSxIjBe49qzmpvka+/usDZha9z123fxdHD76Jpt3Pm8h9iUgfRLArBiYfAYxxhaPRB/Xyduak72L/9x3n51ClePPEZ+m6ZJE0QWsFWFnu3SDxF8FmHXXMtyHuIMYgxZSYadoMOOTgtjR6oTYAEEQfiY1gptazUVABGvE7EgBWObG3RON6hn4WQUkhCFCQKkmIbKYIwyDs8/dxfsL5+lXvvfg87tqxy/sof0WzPoL5Ivsw4nbCgZKRmksO7f4RzC5d56RtfIJM1krTJoN8jd45mowEIXuLgekVsiu+vsK09h3ZX8X6A5Ip6E022RrjClGvL+5hglXBABTOUkAaKE6kldDGhin923rJnts2cXuLq0jWm2k2c9yFzjp/hco8gTLQnkNTw4je+TKM1y923PcrSysusdL9KqzlV7qxic73xPkCEbNDj8O4n0Hw7Xz/5UdYHi7SaLbq9LvOz23j43ofZMjdPNPsYAeM9Yiyri6+z6/yn6Jx/GdcflBiOByRGVhK3exX+aVjhnhBiFvlzDG1VCxsGqlJHn0AEmyasLFzk/XffyY73/jwHtm9BEouYYNtVoNfr8X+efYpXXj/N9PQ0aZry4okn2bvzMPt3fR9fe+VFcptFCKbalW98IuYdiZ1k59xDnD7zGleXTpMk4QbmJrfwY9//k0y1Jhj0e+VKKUG8RpOJlbOknQV8dzXY8hgvGorMEzyuvEmhcNJFQhfMVMi9i5CwvkJ8iUFR5CrO00iV+e415qdn2b1zLxPtdvg8H522tdx19Hb+2x99iOOvn2DL3Bzr66ucPPVVHnnb99FIDrK29hwzMztClnyTmbD5277N+YyJ5k6QHZxdeIV+1sFoSjboc/dt9zLdmmRlaYkszxhkA/qD8DPIMrqdLutXXsUO1hAUaxRjBWNM+LEWmybY1GISwdgEYy0miT9pEn6SFJsm4TmbYpIEm8TXmgRrU4xNsUkaM12YnN5KK7vA5QuvsrK6ynq3Q7fXo9vv0+v3We+soyp873e/g+7KKr1+F2MNZxdO0su6tFvHuH59CZfnoAGke8N3gAh4zWm39tIb5CwtXwqToh7F0UgTvMsxqcUYU1uJ4b25CuuvPU/r7LO00iaSu+gwQwzvpTA7EamM6YBqcNAFni0agtTgC7XMsEuoO35hCEk9ahLE9dHlK2RrawHhdA6TJNUbNERlzVYbN3Csr6wyMzvDWmeZtbUlJtKdrKw6et0uzVYTk8i4nDA0kkny3DHI1kFCZuycI8/zALipDg1+gCwUm3iW59/KC3/1EVQ7OKcxrHMhapHoD3wcfEOw0z7gShKjG2tMxFDDwHv1IcqyRXQSPIVRgxHFWINTZWHiAd4ytwNcXpuoij0QBOcca+vr0EppO8Xljn6/QzOdY23V0+32SNKw68aIhiYRMvY1kiPcvBfdcF0hHhfIHYfufw/9iQO8evoka2vrYUt7jWCYlsbRGhszZCGNUY1zMQKxSTWxQpjAkGeH+FwL1y1YCVCbSVOO7D/A3r17aTQaJNYOcRxaAxFzp+RZjnMukC94vDesrXRY73RptlukDTsmPmCEASvzJS3AuRoLVSOmAkopTDRT7r3rTm699Ra63Q55loeMNzraVmsCK5b+oIdTF56XiggRkQpWLiOdEHSKKt57ImEVM+KYjhhLmqakzQlazQRjzdAC0bhzyutXg7pA1IgBzT3dzoBeLyPLPN6DNeOaAKGMuMUkMYaJz5R3HG5KlGF00QT8ZnJiknarHS7GGgZ5n9/40C8wMTHFI/f+A24/dA/zrZ04zeOOU/DZCMUpZWRUhq21+F5rBH7gCAzWmGpX1nZARYlKLb5XFBfMkwh9l9HPMvJBjvcumM9xTEAdhDIaWIFanBhxw+EdWr9hayonHQbR006mePDOx/nMsx/mtz76y9x+4D7+3T/+EM2kMbShSshihPUtdp+K0u13QmAgDC0AJLCO1HZOYf4o8CitvmgI0rCBsfC5kufBT90MKXZzfEDEQrwn2EjrK3OkwT0arzdM5IoJLCbFR2f5w4//HD/0zp/hP/7JL/OVb3yOv3ruI8xNbCXXHBGD+DCoTpVCF1CYPkFQ77Em5Y5D95HaNr7gBWrctBotJxEENSXGHp8ztakNvksjGaO5Q72r0ZZjMkFSQy81alHietmgh9C6udhsMuKEKbC0fo252W0c2HGMp1/+NP/9z/8DWT7A2ASxJigk1COesIOi70EFI5CkCerh3/70H7B/120Msl7pyIdlLpXpkdrOUhSMR2r4ldbo1zgfuNyjfoyylAJYK2N1lfrOLZFbLyBxchgxB0ODIoITwKZ4r2yZ2UZ/0Oennvgl7jnyMIPcYcVELEICfyzgxMUVm6B+wO9+7F+Te8/W6Z1458rvEKl8RH0X11QDEbUwcUcVOySIBIrlZtLAD3ufl0HF33YnfGd8QCH0kWKF18VOEleYxlVY2O8auV37vSQ8vLJlegeoo5U2OXbgHrr9PolJCylP5CQCBapAI025dO0CS0sLHD1wH9OTW+jl/cDjKptEOxv9b7GgRATvPc5XMIhSBR0l7jQuLChgYq5KXowihqiG0CqxEY1YDZHQjtGIUmp2Rv2KIZiZuakdtBotzl05hRt4+oMumckKNK6MatBwLSIznL74Ete71zm46zaSNEUHveg4dVOzNyqWq/xElTiqgpcKi8Ir6jRC5n6MPqDQ/VRocLklpbYxNmoNS/cboAK0JtoKr3DeMdOeZbI1xZWVRXIflBQBi5cQlZTaH4kiLOXy9VcBYd/2ozUn+012cWESdePuVip0tfxHPa5I8HSMTnhIllJEMT7CBzU2y1QZWMT5pcJoanetRoIMsWBZvaPdmmRmYhtL64skjZTZdK6CbKhECQWDZq1w5tJrTDan2Lf9EJl3paOVTWYiYFoV76a1RVLIUArnLV4R7yMKGzg3vNy0OPimTJAKQ9lpbV1vemHl8xJB/U3A2ILBct7TSieYn9nFq4sv89HP/z6JMQHvqa1RIyY4eA0R0fGzz7F1Zifzs7tweYbcECeQkjErs5UCiqCEkqooSCTgStG2arS0qjJOE0Q5+NRWdqnJGY0QtBw2DAmYinaU8r0FA+BJjGX7lj28fOFZPvLF32Hg+1ixuMxhpEHaaGHizvEoYkIY+tb9jzLVnCPz2QZHP7SFS05h5J5KyaRFVclrGBE+ZNmKBih6nHlAkfKHbRrkHYKWRInWbr5gtcocWXwpY4wvrCKNwrYaw9zEDlZXlnnfg/+U+dlDdPvr7JjfyeLqK5xZPM5EeyJAysZgTcLK+jJH99+FWPMt/GM11QWvWFDLQe0hGFPA2Q7UBT8jBjESwbmaD2KMYWgZnomACbBwGQaNrEAp0M5h/LcKV+NzFks26PPwbY9z6eprrHXXmZtIOLj1Tuam51lavcjy2jUGg3VapsVqtkqWd2knsyxcP0vu83IyTcR9yghnKCGrnHH9egNDNrxhglbXBFl++BVjGN8OKDNbJSjMIops4IYQrR/KjnUoMpKawxYRBnmfg3vewv69t/JnX/x9Xln4JB984l9y71vfxp1H9/IDj/0YrUabl15/mv/6v3+Nbu8ah26/nZ/83n9O7ly5ujc1QVLZfaRKIEt8N6bBEvWjGk2SDFXnBNnjzeQC5uYGnxIPKdN1L1G2t4m5QjeqyEqYWWoGSnHe0UjbnF74On/8qd/mZz/wa7z7wR/lv3zs33P16iUyn5PlGXnu+NAnf5M9247wqx/8Xb74/J/z1y9+gnZrcghrGl39BeNWmskywdJS4iJlEjnsO3LnowPWIXXG2PiA8GtccRqiBdValjziqGSDw5ON0ZOAQzFJghHLyfMvcGnpPO3WNEmjgYoBI4gR2skUC8vnefH158mdo9VM48KgNBebhaE19GEYLa0tmDqliYZyDtFClCw3mwj/7XfAxuoWS6GKDRFQnWXSoYGmbmqicZVaFoqEgc2yHnvnj/BT7/4l/vIrH+bVCyf42Q/8Kq3GNLkP7JdTx0888Ys0bYM//vR/4vve/kHuu/Wd9HqdYDpukCzVfdIQlB2fDDmNj7xGzNqlds1FIlgnnsYBRw+HdREHrQmGi5tyEhhaU6RanlIPWup+4qoLeqAQo/fzHk+8/Sd45K3vJ00aJEmbftYrmbMsH3Bw5zH+zT/8Pbp5n+n2HIOsV+YbMgK+jYJxVYY7kiGU3H8svTJRZRdrD0JljS+UTG98FFRSfRRbNEDERREDIyinQUEsqUkxKlXkU1j9GOJZk9AZrMWYPmzQTn+dNG2jKIOsEx1kZdMHeQ8Qmmmb7mC9xkmwKQo6zA0wtIpLuNxEiaT3gXRRh4/8gzWm0puOKxMuJIQFW6QaYIhQlhWSo5L8UMWahIHvcr3z+hDOHmrGMmzSpNdbZ3H5Ag8efR/97gAxYWcE8ayLrFnNaqrBq5bPeZ+HFW2klnXXL7jYubqBpx69N4mf7SRKWgpTJgaHhJ+46MYGRZSkkdS3rYwUhAY01PsBXzj9IS6vn6BhW1UapC6WuzZ49tSXOHXxJX5m6bd479t+jLXeeglvD/MGBQgpdXVouTOKnSkjtl2KTJaRSRGhADgqcFFKwkmH4GpTRq/fgUT4JqOg4spqq90hG1aFsQnr3WWWu6eZbs+i3uJ8HqIJ28QkTb7y9c9ztbNIvjBLvmQQK6VGZ2MCVVRKuHKQgl5oGOWsopkIfxe81kheIGyGhPqa/4iqCiQSM76ExI2MEQsKOUyQEhpX8Lo6MgEhNDU2wPInzr3ArtmDzM3M4/MMtQ2+fPyLLFw5zfkzy/zwfb/I97/7x+n01kjSRiWw8lWiVvLmWtl6aw2bleQrBXRNTc0cfU6sjlTVkrvWMkn30f6Hf4vqyWIykJhhyzh3gFBiKOXtqos1ATXiQzxi4fradV44+TUuzJ3lgWOPsmVmJ19+8bMsLF3g/Nkudxw4wMMPPMDAe6wRXjpxhhPfOIskJjhCH0PfUpNpykilHtIUdVuBKLJRNJCXzlVRxIc8IjGGx95+O/NbZoM2SaowM/e+VNsFUj5iX4TKIFsXdY0LitARW1qajBg/Fw4tzx2tZsK+uYOcuvQaA/ck040ZFlfOcu70OvceOcY99+1jrd/FYhh4ZW6mzf498xiThJqsePN+A7wg4D0mDpIrymVNzUfEAnlfJt0GEUOSWCZbbdT54bylLnHxUacaIZISiFN/04nYzfWKqJPZQwnZCF0aPbbPc+6+Yx/GWE5eeIX1meucP7PGPQdv46EHjnJl7TJ+ygXFgfPs3T3PgX07aklbscKlFj9KuQo2hUD8cLuCzXKCLMtx9WpP9RHRNYiPlWDeI3H2VAVjPCL+W1Nuf9eUZLh/AUlQ7FDoWRlVj/N9HBmqyr13HqbRgq88+xIPHLmNB++7lYEbIOLJB1n5vkGWo1leMXDRpFUZagUFyAhNtgEk1hvUMo7upBrOL1UYVYa0vsC9vIn0zBgpSa1hnAWDFMr/fRVfx3i6aWew/SmurZ5FWGXbzDSP3nsPU9MpC4tXUIW8K2zddRD1eXDwZnMNkanLCmvRjlA3hWyAGmSTbFhq8vlaPQeigvcuyGRQ1IBTT+o1tl0Agy2TxfHkASiiBvVSskSqVK0J4rL1LmeiOcN73vIrvL7wSrgh77C7LHnusEbw+YDZ6T0cPngHg0GnhIA3Q1VHgbzNWME6EbQZBrQBH4orXpWy3CnoSwPVGYq5Pd5ozOxt7KAy5jzAoyE2liJqNxEn19LmFtj+nu2H2b/vyDA5MMoXDJTOoIMnhyhHL6Hh0ulXiVbZHkEVqwzZ5M1AuMJ8jU6OyEgtQ9mII4rACHSnRrrUk8e2BmM0QZRQvgxlntbaIRRS1ZPaBudXXubiynFsEnyFd8GB5+poNSa4vHaJq0vn+IF7fwGcjUBXxSXX8aMAiElNUiLfVBDwrdD0DbunopYq0t4Eibr3Veg91ky4LCkt9Dp19XINPrAmoZ+v8cXX/pC17CKpbSGkQXmmPdK0xXK3wwunvsTFK6cx3Rl+9J2/wPL68jCwNqIrqj9dCJzrTNtmTcfKv5VFHfXC8NrzPiqijQlFIvHvVsKPwQT7b8z4JiC0pQllPz5mjXitSRFj1imh8Fldl5mJnSSk9F2OOEiSOdZ765x89QVWV3sk52/h4HffjdMMaw2pTWIcrhtwJqkRPoXtNkPgmsa6spocoKbQkIj7O++G+QCthVUanK6xBmukbF1GVGHITcoTb9oJh+825Q07fJyAiJdgwXvSJCFzfZ568fMc2n47B7cdIbcDVtbXeeaVJ1laW2Lx9ev8/Hv+BY889Dir/VX63Zwr62uxn5tgC8FsfZCVWA4V1Bi2iB19qDf2EopcTQGsxXDNEbu9GNg2OxOZsyqmNSbgPOLC60I2LYiNnbJqDNnYVBGbkRuUXGmNtI/Ooj/ocXFxkdXuKqgwN7ONr77yJFeXrnPltVUeffvd7D+wm94gJzGG46+e58UTZ0mtjbB3NYDeD2uKtLDLUuH4qAtCgVgIQh1cMyGfMAIfeOd9zG+dJMsLqU29OFxCLyTNC5066jX0mxunLqje18GrL0OyULDhhySEiGGQDWg2E+7adwcnXj/J8/4Z2g3L9ZUVFk93eeJ7Hmb73ibdbmC7elnGnUf3c8veHWVF/FBBhFYlMjLSLbFqolFkcLWop/43wuTMTLbIc19TZmiZbau6sPrjzi5wIUzsHTROYVbh3bx3ceBdSWQXIJl6BybBAHm2yi17t5JyO8+dOs511+famR7vfecjHDy0gyurC5h2GlVnnoZNaM9Nlc3+NhpAHWnkGkmiEYxmuLebGQqPxXty78oKpUK54Z0LJBMS76+IyVyEwiNhP1Y4usy2NLaaDJMwfPMBM/HeMXB9BiZn/8E5TOMITz39Mu971/0cunWaTn+NzA/I8165gl38Ge4CSw2C0KHNUFfrjMIMlXzEbbKTq10RTJBW762xa6F8tkjwAjY4NnV0yFGisysKMnS4zFMjXeh8zkRjG1v8fbx+4Rm6Jmcy2cO7HtyBEVg8HVTMiT/IwYNvxWkfUYmdLUuMoyo3HVn05UIo8foqvpTNkNORDFi93/QOC6oVI+ANRqVs2iSlIGuciRhV/ZT3BcUY2wjXUn/1ijUNPvDgP2Nl5VrMIH0NWQzZZas9ycTkFFk2CM/ViZ0C69FhFldGLkgYzo7qCaHcIEvWTYIKE2faaGXmwmY3cS/kZQ/RzbCmNygKCtvTO1/a7TL6rNttr2AyuvmAPk3EKEZjJCEBRlYBMk9LsxossLGMacOAjTB0xsjG9gijONINyqOGIIsYTPhIzqChHsjFVsam8i7jd8KmPhLeRxVBRYhbI6x3+3z5mZeZm5uKxHYNOlCPNYarSysc2LeTY4d20e05rN18xY6q3Oq94eoO9kYgXAln32CCqk0UyHpXMGMIakKJpPjQe3RU4PUGg3FVl9mgx1I0Mk11YZZJLKurHVqtJo89dDe9Qb9ms8Nr2s2Ub7y2wNmFa8jh3TFL9RsHR2SorFRGALpCQsJIOayPlfN1qIFN6nwLqYyaooYtZrw+2HwrihpbNND9JgUgb+AOKOxsVaJaRtO17oXgfE6nG3rziOgGX9LPYufcGPUkSUKamGEUtCwEKd0Im4jNq6kZ6toiIwFUSOgGWTYkttWabsgUirhi4qXYGcQ2+mMs0tOCpiotopQV8FXhndSyYx3SQIuYijiJzVa9D0WnxgoLl5a4cPkaRpKAQBJMlQ6xoMMKBwrVs1YZeFl5plHhUNR5xQbjtx/eTauVlHXNke4PlGtdvhJb5oSBd+DdmCtkiH33i2IGGTVPSm3BhjxBa5MTTYX3Ra+fSupuxHDl2jLHT10MvT2LXkCmRkPGSMm5orWZiRB2kTtEXb81WCofUb43rvDD+3fRru2UKon0Q/BFfcJ1yFeMi5SPHa6GcGgtWtRrWd5f1gYX/Tl9CCN8ESER6m5LNQMwGGTccft+bj+2b8jEVK1n6ucC6NDvxU4oeQTqPesqIYGPfaqLosB6KVUBW4szMeavhF8mOuLvhDz9phkxI6HnZwlJ+BoAVyPnvQskx2S7VfaHK3qBqiqtRoNGmsSBiI4zdxtAtFEoYmhBmKJnhDIMUupQ65m6y9BR3KrkBCQIzqSmvSwrK4vGVDdXHXPzfEAkyIsTK7SGUBYFfGqCJmhissXVpSU+/pmnqMcwAStTksRy8dI1bjt6MBRCl+ZpY8g4Gr/Xd8NmCujN3rPZZzEkYwytaQqoO+hHPaoG7yMtaSmxoDElYkFx5jQr4WE/mnlKWP2TE02+5+E7Wby6io1cb4UOBFu+d+cO9u2ap9frb8Ltyg3J9s0Gerh39OYcsSobJpaYJ9RtfqEr8upA0g1tOMe2A7I8qBes2Nh7OVxkmbioVmq13DEzNcn83PQQXSm1QnrvlX4/q57TzXPejSHljQswblScoRvMVC2krj1fmFcjSjNJGWRZEAUjiOemtaE3QWgKa51F0qYwPTkXYOeoTnj9zJnQD9QanK+OLsmznE53QKfbp9Pt0+tndLoD1jt91jt9ur1+2NpFMXSEK8royGspF9Fo8tT7sojCxxqFoglrSZ6U76tFbJFdU6fla3zEpBupZa2To7HTgfeOZqPN9OQ8SyuLZK4fOueqjssJK9ZYriyf4XbrObDvGK+ePY7znrTZ4PmXXmDn3B4eevAu2hOTlTkq64CrKkSt6fILEVQpOSmKLwrDHON3KaDj0szJEAlfHKFV8gXlqpaIIROK/AoYWoLDD2i/58KF67xw/DV6/S5bzSz9LOPwwX3MTG/h/IVXcNrDWBPp4jFAEd4radri4uJprlw7xZHDd/L88S+xsnqFyeYEV9YW+fCf/Slfe+kku/buJLE2FGmUJUwhAfOx+6G1SVncbYyU5aKuJg8sSpYClhOz2IgzaYnnV1NatjQ2VXY81P44frYvm61oqWXq9x1PPv1Zcp9jkwRFufuOh+l2u5x85SkaaRg2a834tKFGLOIznnvhf/H4I/+Kh+5/jE9+9k/I8wGzM7O8evkVnn7+Io0TExhpRNlINCVSRBpxcK0J6UQ0HcYGIr+KKKVMtIquvUVfgdHOvKoeFyso6z1HK11/taMMhGrL2EmxKMS7vHiBlbUrHD58K53OCm978HFuOXgbzzzzJKdOf4lde+ZjSwY/HjRUBLI8Z25uO88+/wmsHOXRt/0wnQfXefLpjyMW9h7Yy8Vz57h27SK9fkbmMnweCG9TkObRGYdYP9r7ojd/XPWlzS6crg/HXoW/h6NT/IizDq8Jg11BIPEnVmB6iZGOi/CICScpJdYyOdnmwMFDON/jzqMP8I5HPsD5s+f45Gf/MyZZp9HcgrVJIPvHSUkaC3v2zvMXn/l1sp7wrsd+iMmZGb7w1Me5dm2Brdu3M7tlC9nAk8cCOmrJV62yIxZyDKOXJb40nMOWnK83oSMuqhuyYq9Fx9w4aUVIKiZMTNmXOrzfmvCdOaEXnE0sDz3wLh5/7AdZvHSFj37sN7h89Tn27tlDYgxJmpLYBDPOlmWosGPbFg4emuZ//umvcH35Mu9/4h/x4z94Cy+dfIbTZ17k6tUrrK+vk2XxiKg4UB5BvAuFESJYsaipLHix0oO/Dj6j6FQlBQccO7SUrcVKOCGqGGwIFQPBTsTvTalnDeR7xV2ntsHU9Cx7dh7k/nu+i917jvDSC8/zqU/9Dq8sfJq9e3aRNlIazZTUGqwFHV+JkmJMON3o0NGDXF/u8xef/XVOnfoq73zsg9z9lrdz/53fw1pvmbVOB5dnJWHja21pKLEdU4b7Wne+ENvYaCV9KfrzxoMbxCvehzpea23ZR64CzzSWudqS7SLuOKnkELQaLaZm5hAMCxde54//x2/y9HMfYcAie3btotVq0Wg3aDYTGlawiUGSmzvG5OZ0QWIwkjLZSnjrXbeRSsqJEx/j+d/7BLfufzvHDj/I9p2HmZvdhU2SCiAzAUWVSOhXNKJUB6ZpID5CNxYXcSVfNk1yzqHGhCBHqzJV733E8E3JzIWRjq0tFZzLI3EUDzmJiWO3t8bilQucPvM1Tr/2ZVb7Z5ifn2X//E5arZRWu0m73aA90abRbpIkdryEjEhCkihWPTOzLW49upvJqRbnFxa5fPGvee0Ln4tqswTvQ7E1BRKqYSCtERBbntkoUiREGhtmm9ArWs2QPtTlrtZWTEt60Lk8hrbxcE6viLExOioarzpsPMrQl22JfTi4rWFIU8PMzARH9h9kqt3GJtCYaDE50aQ90aI1kZI2LTYxN6xjeGMmIE6CoDRSy9Ytc4gxTExOsnv7DpY763R7Pfr9nCzv452POnsTjhCsQw4KiQ2RjnPxnF6TVBhM7IprpN7SJp6g5Cj70KkG3WdoJxCl5NErFxvIJBHFjItAIvJpraWRpjQaCY1mQpqmNJuWNLGkjZR2u0GrnZKkliQJEZgda8MmIZ794jEGmo0WW2aFJGky0W4wOWgx6OU4p6V6TjWu9OKsASqowhZlf6Zo5m2rtjEKlnr7s9jtR23oaFg0Wg0uNrzOxXYaPgqGJcF7h00KPD/0oRYJXRvLkzmMp5k0aLYa2EZCI0loNRKMERoNg00amMRiDcOi3jeeDxhuVyMW0kaDSYQ0NUzkTbJBRp4XSKkfQkFVJZ6uFGsMyrb3EYFUqU4w1VBnqjXOuADwgvrOVCtdQ9TvRLEx1HXqcV7CQZ9GSniiODO06h8S+08LIdRMQ8iZJkk0bYJYg1jdcBj6G2+Cor6ndEQmRCGNhsX7NAJpI4UbqkON2sqqIq0gBEZINhEYqf6op13DOqVaHwmV6tyCiqyrM/k61LRpSPIixdmRxVkHZkiRZ+L7jdjxnCNWXsQmZ8oHRUM6lDl/08Xy7SykG75mszPjvw0px7f8lBr7pnrDbxhr+/pvrpjQDcTHNx2jb+c+9G/2xtHDHf5G3a1k6Jy+v7NHwv/Hjw17U/7+XaPhzcebE/DmBLz5GNvj/wJIR4sGdpBBMwAAAABJRU5ErkJggg==" alt="Lista de Compras" style={{ width: 96, height: 96, borderRadius: 22, marginBottom: 10, display: "block", margin: "0 auto 10px" }} />
            <div style={{ fontSize: fs + 8, fontWeight: "bold", color: t.accent }}>Lista de Compras</div>
            <div style={{ fontSize: fs - 2, color: t.text3, marginTop: 6 }}>Versão 1.6</div>
          </div>

          {/* Info cards */}
          {[
            { icon: "👨‍💻", label: "Desenvolvedor", value: "William Santos" },
            { icon: "✉️", label: "Contato", value: "thespation@gmail.com" },
          ].map(({ icon, label, value }) => (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 16px", background: t.bg2, border: `1px solid ${t.border}`, borderRadius: 12, marginBottom: 10 }}>
              <span style={{ fontSize: fs + 4 }}>{icon}</span>
              <div>
                <div style={{ fontSize: fs - 3, color: t.text3 }}>{label}</div>
                <div style={{ fontSize: fs, color: t.text, fontWeight: "bold", marginTop: 2 }}>{value}</div>
              </div>
            </div>
          ))}

          {/* ── Check for updates ── */}
          <div style={{ marginTop: 16, marginBottom: 16 }}>
            <button
              onClick={checkForUpdate}
              disabled={updateStatus === "checking"}
              style={{ width: "100%", padding: "14px", background: updateStatus === "available" ? t.accentBg : t.bg2, border: `1px solid ${updateStatus === "available" ? t.accent : t.border}`, borderRadius: 12, color: updateStatus === "available" ? t.accent : t.text2, fontSize: fs - 1, fontFamily: "inherit", cursor: updateStatus === "checking" ? "default" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 10, fontWeight: updateStatus === "available" ? "bold" : "normal" }}
            >
              {updateStatus === "checking" && <span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>⏳</span>}
              {updateStatus === "available" && <span>🆕</span>}
              {updateStatus === "up-to-date" && <span>✅</span>}
              {updateStatus === "error" && <span>⚠️</span>}
              {(!updateStatus) && <span>🔄</span>}
              <span>
                {updateStatus === "checking" && "Verificando..."}
                {updateStatus === "up-to-date" && "Você está na versão mais recente!"}
                {updateStatus === "available" && `Nova versão disponível: v${updateInfo.version}`}
                {updateStatus === "error" && "Falha ao verificar — tente novamente"}
                {!updateStatus && "Verificar atualização"}
              </span>
            </button>

            {/* Update available — changelog + download button */}
            {updateStatus === "available" && updateInfo && (
              <div style={{ marginTop: 10, background: t.bg2, border: `1px solid ${t.accentBorder}`, borderRadius: 12, overflow: "hidden" }}>
                {updateInfo.body ? (
                  <div style={{ padding: "14px 16px", borderBottom: `1px solid ${t.border}` }}>
                    <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 6, fontWeight: "bold", letterSpacing: 0.5 }}>O QUE HÁ DE NOVO</div>
                    <div style={{ fontSize: fs - 2, color: t.text2, lineHeight: 1.7, whiteSpace: "pre-wrap" }}>{updateInfo.body}</div>
                  </div>
                ) : null}
                <button
                  onClick={() => {
                    const url = updateInfo.url || "https://github.com/thespation/lista-compras-android/releases";
                    if (window.AndroidBridge && window.AndroidBridge.openUrl) {
                      window.AndroidBridge.openUrl(url);
                    } else {
                      window.open(url, "_blank");
                    }
                  }}
                  style={{ ...primaryBtn, width: "100%", borderRadius: 0, borderBottomLeftRadius: 12, borderBottomRightRadius: 12, margin: 0 }}
                >
                  ⬇️ BAIXAR ATUALIZAÇÃO
                </button>
              </div>
            )}
          </div>

          <div style={{ padding: "14px 16px", background: t.accentBg, border: `1px solid ${t.accentBorder}`, borderRadius: 12, fontSize: fs - 3, color: t.text3, lineHeight: 1.7, textAlign: "center" }}>
            App desenvolvido para uso pessoal.<br/>
            Seus dados ficam salvos localmente no celular.
          </div>
        </div>
      )}

      {/* -- CUSTOM PALETTE EDITOR MODAL -- */}
      {customPaletteEditor && (() => {
        const e = customPaletteEditor;
        const preview = buildCustomPalette(e);
        const ColorField = ({ label, value, onChange }) => (
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
            <div style={{ flex: 1, fontSize: fs - 3, color: t.text2 }}>{label}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: value, border: `2px solid ${t.border}`, flexShrink: 0 }} />
              <input
                type="color"
                value={value}
                onChange={(ev) => onChange(ev.target.value)}
                style={{ width: 38, height: 38, border: "none", borderRadius: 8, cursor: "pointer", background: "none", padding: 0 }}
              />
              <input
                type="text"
                value={value}
                onChange={(ev) => { if (/^#[0-9a-fA-F]{0,6}$/.test(ev.target.value)) onChange(ev.target.value); }}
                style={{ ...inp, width: 90, padding: "6px 8px", fontSize: fs - 3, marginTop: 0, fontFamily: "monospace" }}
              />
            </div>
          </div>
        );
        return (
          <div style={{ position: "fixed", inset: 0, zIndex: 900, display: "flex", flexDirection: "column" }}>
            <div onClick={() => setCustomPaletteEditor(null)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }} />
            <div style={{ position: "relative", zIndex: 1, marginTop: "auto", width: "100%", maxWidth: 430, marginLeft: "auto", marginRight: "auto", background: t.bg2, borderRadius: "20px 20px 0 0", maxHeight: "90vh", display: "flex", flexDirection: "column", border: `1px solid ${t.border}`, boxShadow: "0 -8px 40px rgba(0,0,0,0.6)" }}>
              {/* Header */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 20px 12px", borderBottom: `1px solid ${t.border}`, flexShrink: 0 }}>
                <div style={{ fontSize: fs + 1, fontWeight: "bold" }}>🎨 Paleta Personalizada</div>
                <button onClick={() => setCustomPaletteEditor(null)} style={{ background: t.bg3, border: "none", color: t.text2, width: 32, height: 32, borderRadius: 8, cursor: "pointer", fontSize: 16 }}>✕</button>
              </div>

              <div style={{ overflowY: "auto", flex: 1, padding: "16px 20px 24px" }}>
                {/* Name */}
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 6, fontWeight: "bold", letterSpacing: 0.5 }}>NOME DA PALETA</div>
                  <input
                    value={e.name}
                    onChange={(ev) => setCustomPaletteEditor((p) => ({ ...p, name: ev.target.value }))}
                    style={{ ...inp, marginTop: 0 }}
                    placeholder="Ex: Meu Tema"
                  />
                </div>

                {/* Dark mode colors */}
                <div style={{ marginBottom: 16, background: t.bg3, borderRadius: 12, padding: "14px 14px 6px" }}>
                  <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 12, fontWeight: "bold", letterSpacing: 0.5 }}>🌙 MODO ESCURO</div>
                  <ColorField label="Cor de fundo"  value={e.darkBg}     onChange={(v) => setCustomPaletteEditor((p) => ({ ...p, darkBg: v }))} />
                  <ColorField label="Cor de destaque" value={e.darkAccent} onChange={(v) => setCustomPaletteEditor((p) => ({ ...p, darkAccent: v }))} />
                </div>

                {/* Light mode colors */}
                <div style={{ marginBottom: 16, background: t.bg3, borderRadius: 12, padding: "14px 14px 6px" }}>
                  <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 12, fontWeight: "bold", letterSpacing: 0.5 }}>☀️ MODO CLARO</div>
                  <ColorField label="Cor de fundo"   value={e.lightBg}     onChange={(v) => setCustomPaletteEditor((p) => ({ ...p, lightBg: v }))} />
                  <ColorField label="Cor de destaque" value={e.lightAccent} onChange={(v) => setCustomPaletteEditor((p) => ({ ...p, lightAccent: v }))} />
                </div>

                {/* Preview */}
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 8, fontWeight: "bold", letterSpacing: 0.5 }}>PRÉVIA</div>
                  <div style={{ display: "flex", gap: 8 }}>
                    {[["🌙", preview.dark], ["☀️", preview.light]].map(([icon, pt]) => (
                      <div key={icon} style={{ flex: 1, background: pt.bg, borderRadius: 12, padding: 12, border: `1px solid ${pt.border}` }}>
                        <div style={{ fontSize: fs - 3, color: pt.text3, marginBottom: 6 }}>{icon} {e.name || "Paleta"}</div>
                        <div style={{ background: pt.bg2, borderRadius: 8, padding: "8px 10px", marginBottom: 6 }}>
                          <div style={{ fontSize: fs - 2, color: pt.accent, fontWeight: "bold" }}>R$ 42,50</div>
                          <div style={{ fontSize: fs - 5, color: pt.text3 }}>3 itens</div>
                        </div>
                        <div style={{ display: "flex", gap: 4 }}>
                          <div style={{ flex: 1, height: 6, borderRadius: 3, background: pt.accent }} />
                          <div style={{ flex: 1, height: 6, borderRadius: 3, background: pt.bg3 }} />
                          <div style={{ flex: 1, height: 6, borderRadius: 3, background: pt.bg3 }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Save */}
                <button
                  onClick={saveCustomPalette}
                  disabled={!e.name.trim()}
                  style={{ ...primaryBtn, opacity: e.name.trim() ? 1 : 0.5 }}
                >
                  ✓ SALVAR PALETA
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* -- BACKUP MANAGER MODAL -- */}
      {backupManager && (
        <div style={{ position: "fixed", inset: 0, zIndex: 800, display: "flex", flexDirection: "column" }}>
          <div onClick={() => setBackupManager(null)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }} />
          <div style={{ position: "relative", zIndex: 1, marginTop: "auto", width: "100%", maxWidth: 430, marginLeft: "auto", marginRight: "auto", background: t.bg2, borderRadius: "20px 20px 0 0", maxHeight: "80vh", display: "flex", flexDirection: "column", border: `1px solid ${t.border}`, boxShadow: "0 -8px 40px rgba(0,0,0,0.6)" }}>
            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 20px 12px" }}>
              <div>
                <div style={{ fontSize: fs + 1, fontWeight: "bold" }}>📂 Backups salvos</div>
                <div style={{ fontSize: fs - 3, color: t.text3, marginTop: 2 }}>{backupManager.backups.length} backup{backupManager.backups.length !== 1 ? "s" : ""} encontrado{backupManager.backups.length !== 1 ? "s" : ""}</div>
              </div>
              <button onClick={() => setBackupManager(null)} style={{ background: t.bg3, border: "none", color: t.text2, width: 32, height: 32, borderRadius: 8, cursor: "pointer", fontSize: 16 }}>✕</button>
            </div>
            {/* List */}
            <div style={{ overflowY: "auto", flex: 1, padding: "0 20px 20px" }}>
              {backupManager.backups.length === 0 ? (
                <div style={{ textAlign: "center", padding: "40px 0", color: t.text4 }}>
                  <div style={{ fontSize: 32 }}>🗄️</div>
                  <div style={{ marginTop: 10, fontSize: fs - 1 }}>Nenhum backup ainda</div>
                  <div style={{ marginTop: 6, fontSize: fs - 3, color: t.text3 }}>Toque em "Salvar backup agora" para criar um.</div>
                </div>
              ) : backupManager.backups.map((backup) => (
                <div key={backup.key} style={{ background: t.bg3, border: `1px solid ${t.border}`, borderRadius: 12, padding: "12px 14px", marginBottom: 10 }}>
                  <div style={{ fontSize: fs - 1, fontWeight: "bold", marginBottom: 4 }}>{backup.name}</div>
                  <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 10 }}>
                    {backup.lists} lista{backup.lists !== 1 ? "s" : ""} · {(backup.size / 1024).toFixed(1)} KB
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      onClick={() => restoreBackup(backup)}
                      style={{ flex: 1, padding: "9px", background: t.accentBg, color: t.accent, border: `1px solid ${t.accentBorder}`, borderRadius: 8, fontSize: fs - 2, fontFamily: "inherit", fontWeight: "bold", cursor: "pointer" }}>
                      ↩ Restaurar
                    </button>
                    <button
                      onClick={() => setConfirmModal({
                        title: "🗑 Excluir backup?",
                        message: `Excluir "${backup.name}"? Esta ação não pode ser desfeita.`,
                        onConfirm: () => deleteBackup(backup.key),
                      })}
                      style={{ padding: "9px 14px", background: t.upBg, color: t.up, border: `1px solid ${t.up}33`, borderRadius: 8, fontSize: fs - 2, fontFamily: "inherit", cursor: "pointer" }}>
                      🗑
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* -- CONFIRM MODAL (replaces window.confirm for Android WebView) -- */}
      {confirmModal && (
        <div style={{ position: "fixed", inset: 0, zIndex: 800, display: "flex", alignItems: "center", justifyContent: "center", padding: "0 24px" }}>
          <div onClick={() => setConfirmModal(null)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }} />
          <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: 380, background: t.bg2, borderRadius: 18, padding: 24, border: `1px solid ${t.border}`, boxShadow: "0 8px 40px rgba(0,0,0,0.6)" }}>
            <div style={{ fontSize: fs + 2, fontWeight: "bold", marginBottom: 12, color: t.up }}>{confirmModal.title}</div>
            <div style={{ fontSize: fs - 1, color: t.text2, lineHeight: 1.6, marginBottom: 24 }}>{confirmModal.message}</div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setConfirmModal(null)} style={{ flex: 1, padding: "12px", background: t.bg3, color: t.text, border: `1px solid ${t.border}`, borderRadius: 10, fontSize: fs - 1, fontFamily: "inherit", cursor: "pointer" }}>
                {confirmModal.cancelLabel || "Cancelar"}
              </button>
              <button onClick={() => { confirmModal.onConfirm(); setConfirmModal(null); }} style={{ flex: 1, padding: "12px", background: t.upBg, color: t.up, border: `1px solid ${t.up}44`, borderRadius: 10, fontSize: fs - 1, fontFamily: "inherit", fontWeight: "bold", cursor: "pointer" }}>
                {confirmModal.confirmLabel || "Confirmar"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* -- IMPORT CONFIRM MODAL -- */}
      {importConfirm && (
        <div style={{ position: "fixed", inset: 0, zIndex: 800, display: "flex", alignItems: "center", justifyContent: "center", padding: "0 24px" }}>
          <div onClick={() => setImportConfirm(null)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }} />
          <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: 380, background: t.bg2, borderRadius: 18, padding: 24, border: `1px solid ${t.border}`, boxShadow: "0 8px 40px rgba(0,0,0,0.6)" }}>
            <div style={{ fontSize: fs + 2, fontWeight: "bold", marginBottom: 12 }}>📂 Restaurar backup?</div>
            <div style={{ fontSize: fs - 2, color: t.text3, marginBottom: 8 }}>Arquivo: {importConfirm.filename}</div>
            <div style={{ fontSize: fs - 1, color: t.text2, lineHeight: 1.6, marginBottom: 8 }}>
              Serão importadas <strong style={{ color: t.accent }}>{importConfirm.parsed.lists.length} listas</strong>.
            </div>
            <div style={{ fontSize: fs - 2, padding: "10px 12px", background: t.upBg, color: t.up, borderRadius: 8, marginBottom: 24, lineHeight: 1.5 }}>
              ⚠️ Atenção: os dados atuais serão substituídos. Esta ação não pode ser desfeita.
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setImportConfirm(null)} style={{ flex: 1, padding: "12px", background: t.bg3, color: t.text, border: `1px solid ${t.border}`, borderRadius: 10, fontSize: fs - 1, fontFamily: "inherit", cursor: "pointer" }}>
                Cancelar
              </button>
              <button onClick={confirmImport} style={{ flex: 1, padding: "12px", background: t.accent, color: t.accentText, border: "none", borderRadius: 10, fontSize: fs - 1, fontFamily: "inherit", fontWeight: "bold", cursor: "pointer" }}>
                Restaurar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* -- EDIT ITEM MODAL -- */}
      {editingItem && (
        <div style={{ position: "fixed", inset: 0, zIndex: 700, display: "flex", alignItems: "flex-end" }}>
          <div onClick={() => setEditingItem(null)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.65)", backdropFilter: "blur(4px)" }} />
          <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: 430, margin: "0 auto", background: t.bg2, borderRadius: "20px 20px 0 0", padding: "22px 22px 40px", border: `1px solid ${t.border}`, boxShadow: "0 -8px 40px rgba(0,0,0,0.5)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
              <h3 style={{ margin: 0, fontWeight: "normal", fontSize: fs + 4 }}>Editar Item</h3>
              <button onClick={() => setEditingItem(null)} style={{ background: t.bg3, border: "none", color: t.text2, width: 32, height: 32, borderRadius: 8, cursor: "pointer", fontSize: fs + 1 }}>✕</button>
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: fs - 4, letterSpacing: 2, color: t.text3 }}>PRODUTO</label>
              <input value={editingItem.name} onChange={(e) => setEditingItem((i) => ({ ...i, name: e.target.value }))} style={inp} autoFocus />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
              <div>
                <label style={{ fontSize: fs - 4, letterSpacing: 2, color: t.text3 }}>QUANTIDADE</label>
                <input
                  type="number"
                  value={editingItem.qty}
                  onChange={(e) => setEditingItem((i) => ({ ...i, qty: String(Math.max(1, Math.round(parseFloat(e.target.value) || 1))) }))}
                  style={inp}
                  min="1"
                  step="1"
                />
              </div>
              <div>
                <label style={{ fontSize: fs - 4, letterSpacing: 2, color: t.text3 }}>VALOR UNIT.</label>
                <div style={{ position: "relative" }}>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={editingItem.price}
                    onChange={(e) => setEditingItem((i) => ({ ...i, price: maskCurrency(e.target.value) }))}
                    style={{ ...inp, paddingRight: 30 }}
                    placeholder="0,00"
                  />
                  {(() => {
                    const hint = getPriceHint(editingItem.name, unmaskCurrency(editingItem.price), currentList?.date, currentList?.market);
                    if (!hint) return null;
                    return (
                      <div style={{
                        position: "absolute", top: "50%", right: 8, transform: "translateY(-50%)",
                        fontSize: fs - 4, fontWeight: "bold", lineHeight: 1,
                        color: hint.arrow === "down" ? t.down : t.up,
                        display: "flex", flexDirection: "column", alignItems: "center", gap: 1,
                        pointerEvents: "none",
                      }}>
                        <span>{hint.arrow === "down" ? "▼" : "▲"}</span>
                        <span style={{ fontSize: fs - 7 }}>{hint.pct.toFixed(0)}%</span>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>
            {/* Price hint explanation when visible */}
            {(() => {
              const hint = getPriceHint(editingItem.name, unmaskCurrency(editingItem.price), currentList?.date, currentList?.market);
              if (!hint) return null;
              return (
                <div style={{ marginBottom: 12, fontSize: fs - 4, color: hint.arrow === "down" ? t.down : t.up, display: "flex", alignItems: "center", gap: 6, padding: "6px 10px", background: hint.arrow === "down" ? t.downBg : t.upBg, borderRadius: 8 }}>
                  <span style={{ fontSize: fs - 2 }}>{hint.arrow === "down" ? "▼" : "▲"}</span>
                  <span>
                    {hint.arrow === "down" ? "Mais barato" : "Mais caro"} que a última compra ({fmt(hint.lastPrice)}) — {hint.pct.toFixed(1)}%
                  </span>
                </div>
              );
            })()}
            {editingItem.price && editingItem.qty && (
              <div style={{ background: t.bg3, borderRadius: 10, padding: "10px 14px", marginBottom: 14, display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: t.text3, fontSize: fs - 2 }}>Subtotal</span>
                <span style={{ color: t.accent, fontWeight: "bold" }}>
                  {fmt(unmaskCurrency(editingItem.price || "0") * (parseInt(editingItem.qty, 10) || 1))}
                </span>
              </div>
            )}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <button
                onClick={() => { removeItem(editingItem.id); setEditingItem(null); showToast("Item removido"); }}
                style={{ padding: "12px", background: t.upBg, color: t.up, border: `1px solid ${t.up}33`, borderRadius: 10, fontSize: fs - 1, cursor: "pointer", fontFamily: "inherit", fontWeight: "bold" }}
              >
                🗑 REMOVER
              </button>
              <button onClick={saveEditItem} style={primaryBtn}>✓ SALVAR</button>
            </div>
          </div>
        </div>
      )}

      {/* -- EDIT LIST HEADER MODAL -- */}
      {editingListHeader && currentList && (
        <div style={{ position: "fixed", inset: 0, zIndex: 800, display: "flex", alignItems: "center", justifyContent: "center", padding: "0 24px" }}>
          <div onClick={() => setEditingListHeader(false)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }} />
          <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: 380, background: t.bg2, borderRadius: 18, padding: 24, border: `1px solid ${t.border}`, boxShadow: "0 8px 40px rgba(0,0,0,0.6)" }}>
            <div style={{ fontSize: fs + 2, fontWeight: "bold", marginBottom: 18 }}>✏️ Editar lista</div>

            <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 5 }}>Nome da lista</div>
            <input
              value={editListName}
              onChange={(e) => setEditListName(e.target.value)}
              autoFocus
              style={{ ...inp, marginBottom: 16 }}
            />

            <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 8 }}>Mercado</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 20 }}>
              {markets.map((m) => (
                <div
                  key={m}
                  onClick={() => setEditListMarket(m)}
                  style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: editListMarket === m ? t.accentBg : t.bg3, border: `1px solid ${editListMarket === m ? t.accent : t.border}`, borderRadius: 10, cursor: "pointer" }}
                >
                  <div style={{ width: 16, height: 16, borderRadius: "50%", border: `2px solid ${editListMarket === m ? t.accent : t.text4}`, background: editListMarket === m ? t.accent : "transparent", flexShrink: 0 }} />
                  <span style={{ fontSize: fs - 1, color: editListMarket === m ? t.accent : t.text, fontWeight: editListMarket === m ? "bold" : "normal" }}>{m}</span>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setEditingListHeader(false)} style={{ flex: 1, padding: "12px", background: t.bg3, color: t.text2, border: `1px solid ${t.border}`, borderRadius: 10, fontSize: fs - 1, fontFamily: "inherit", cursor: "pointer" }}>
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (!editListName.trim()) return;
                  updateList(currentList.id, (l) => ({ ...l, name: editListName.trim(), market: editListMarket }));
                  setEditingListHeader(false);
                  showToast("Lista atualizada!");
                }}
                style={{ ...primaryBtn, flex: 1 }}
              >
                ✓ Salvar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* -- DUPLICATE MODAL -- */}
      {duplicateSource && (
        <div style={{ position: "fixed", inset: 0, zIndex: 700, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
          <div onClick={() => setDuplicateSource(null)} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.65)", backdropFilter: "blur(4px)" }} />
          <div style={{ position: "relative", zIndex: 1, width: "100%", maxWidth: 380, background: t.bg2, borderRadius: 16, padding: 24, border: `1px solid ${t.border}`, boxShadow: `0 8px 40px rgba(0,0,0,0.5)` }}>
            <h3 style={{ margin: "0 0 6px", fontWeight: "normal", fontSize: fs + 3 }}>Duplicar Lista</h3>
            <p style={{ margin: "0 0 16px", fontSize: fs - 2, color: t.text3 }}>"{duplicateSource.name}"</p>

            {/* Market selector */}
            <div style={{ fontSize: fs - 3, color: t.text3, marginBottom: 6 }}>Mercado</div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
              {markets.map((m) => (
                <button key={m} onClick={() => setDuplicateMarket(m)}
                  style={{ padding: "6px 12px", fontSize: fs - 3, fontFamily: "inherit", borderRadius: 8, cursor: "pointer", background: duplicateMarket === m ? t.accentBg : t.bg3, border: `1px solid ${duplicateMarket === m ? t.accent : t.border}`, color: duplicateMarket === m ? t.accent : t.text2, fontWeight: duplicateMarket === m ? "bold" : "normal" }}
                >{m}</button>
              ))}
            </div>

            {/* Zero values toggle */}
            <div
              onClick={() => setDuplicateZero((v) => !v)}
              style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: 14, background: t.bg3, borderRadius: 10, cursor: "pointer", marginBottom: 20, border: `1px solid ${duplicateZero ? t.accent : t.border}` }}
            >
              <div style={{ width: 20, height: 20, borderRadius: 5, border: `2px solid ${duplicateZero ? t.accent : t.bg4}`, background: duplicateZero ? t.accent : "transparent", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: t.accentText, flexShrink: 0, marginTop: 1 }}>
                {duplicateZero ? "✓" : ""}
              </div>
              <div>
                <div style={{ fontSize: fs - 1, color: duplicateZero ? t.accent : t.text, fontWeight: duplicateZero ? "bold" : "normal" }}>
                  Zerar todos os valores
                </div>
                <div style={{ fontSize: fs - 4, color: t.text3, marginTop: 3, lineHeight: 1.5 }}>
                  Itens copiados com preço R$0,00 para preencher na hora das compras
                </div>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <button
                onClick={() => setDuplicateSource(null)}
                style={{ padding: "12px", background: t.bg3, color: t.text2, border: `1px solid ${t.border}`, borderRadius: 10, fontSize: fs - 1, cursor: "pointer", fontFamily: "inherit" }}
              >
                Cancelar
              </button>
              <button onClick={doDuplicate} style={primaryBtn}>⧉ DUPLICAR</button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
